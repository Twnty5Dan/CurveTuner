# CurveTuner - Curve Optimizer values from Windows, through ryzen-smu-cli (needs PawnIO and admin rights)
# Values set here are temporary: every reboot brings back the BIOS values.

$script:Applied = $null   # the values currently applied, as last read back (int[12])

function Get-SmuExe { Join-Path $CcDir 'tools\ryzen-smu-cli\ryzen-smu-cli.exe' }

function Invoke-SmuCli([string] $Arguments) {
    $psi = New-Object Diagnostics.ProcessStartInfo (Get-SmuExe)
    $psi.Arguments              = $Arguments
    $psi.UseShellExecute        = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.CreateNoWindow         = $true

    $p = [Diagnostics.Process]::Start($psi)
    $errTask = $p.StandardError.ReadToEndAsync()
    $out = $p.StandardOutput.ReadToEnd()
    if (-not $p.WaitForExit(30000)) {
        try { $p.Kill() } catch { }
        throw 'ryzen-smu-cli did not respond'
    }
    return [pscustomobject]@{ ExitCode = $p.ExitCode; Output = ($out + "`n" + $errTask.Result).Trim() }
}

function Get-CoOffsets {
    $last = ''
    for ($try = 1; $try -le 3; $try++) {
        $r = Invoke-SmuCli '--get-offsets-terse'
        $last = $r.Output
        $line = $r.Output -split "`r?`n" | Where-Object { $_ -match '^\s*-?\d+(\s*,\s*-?\d+)+\s*$' } | Select-Object -Last 1
        if ($r.ExitCode -eq 0 -and $line) {
            $values = @($line -split ',' | ForEach-Object { [int]$_.Trim() })
            if ($values.Count -eq $Config.NumCores) {
                $script:Applied = $values
                return ,$values
            }
        }
        Start-Sleep -Seconds 2
    }
    throw "Could not read the Curve Optimizer values: $last"
}

# $Values: hashtable core -> value. Only those cores change. Always verified by reading back.
function Set-CoOffsets([hashtable] $Values) {
    if ($Values.Count -eq 0) { return }

    $parts = @()
    foreach ($core in ($Values.Keys | Sort-Object)) {
        $c = [int]$core
        $v = [int]$Values[$core]
        if ($c -lt 0 -or $c -ge $Config.NumCores) { throw "Invalid core number $c" }
        if ($v -lt $Config.MinValue -or $v -gt $Config.MaxValue) { throw "Refusing to set core $c to $v (allowed: $($Config.MinValue) to $($Config.MaxValue))" }
        $parts += ('{0}:{1}' -f $c, $v)
    }
    $arguments = '--offset ' + ($parts -join ',')

    for ($try = 1; $try -le 2; $try++) {
        $r   = Invoke-SmuCli $arguments
        $now = Get-CoOffsets
        $ok  = $true
        foreach ($core in $Values.Keys) {
            if ($now[[int]$core] -ne [int]$Values[$core]) { $ok = $false }
        }
        if ($ok) {
            Write-Log ('Applied ' + ($parts -join ',') + '  ->  ' + ($now -join ','))
            return
        }
        Write-Log ("'$arguments' did not apply (exit $($r.ExitCode)): $($r.Output)")
    }
    throw ('Could not set the Curve Optimizer values (' + ($parts -join ',') + ')')
}

function Set-AllCoOffsets($Values) {
    $h = @{}
    for ($i = 0; $i -lt $Config.NumCores; $i++) { $h[$i] = [int]@($Values)[$i] }
    Set-CoOffsets $h
}
