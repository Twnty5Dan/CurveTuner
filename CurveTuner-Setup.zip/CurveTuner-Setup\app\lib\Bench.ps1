# CurveTuner - benchmarks (effective clock + score) and the idle/boost-spike test

$BenchSource = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

public static class CtBench {
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentThread();
    [DllImport("kernel32.dll")] static extern UIntPtr SetThreadAffinityMask(IntPtr thread, UIntPtr mask);

    public static ulong Sink;

    // Four integer chains and one FP chain, all in registers: the speed only depends on the core clock
    static ulong Block(ulong a, int n) {
        ulong b = a ^ 0x9E3779B97F4A7C15UL, c = a + 12345, d = a * 31;
        double f = 1.0;
        for (int i = 0; i < n; i++) {
            a ^= a << 13; a ^= a >> 7;  a ^= a << 17;
            b ^= b << 13; b ^= b >> 7;  b ^= b << 17;
            c = c * 6364136223846793005UL + 1442695040888963407UL;
            d = (d + c) ^ (d >> 3);
            f = f * 1.0000000001 + 1e-12;
        }
        return a ^ b ^ c ^ d ^ (ulong)f;
    }

    const ulong CheckSeed = 0x5DEECE66DUL;
    const int   CheckN    = 2000;
    static readonly ulong Expected  = Block(CheckSeed, CheckN);
    static readonly ulong Expected2 = Block(CheckSeed, CheckN);

    static void Pin(int cpu) {
        Thread.BeginThreadAffinity();
        SetThreadAffinityMask(GetCurrentThread(), new UIntPtr(1UL << cpu));
    }

    // Million iterations per second for each chunk, on one logical CPU
    static double[] Worker(int cpu, int warmupMs, int chunks, int chunkMs) {
        Pin(cpu);
        Thread.CurrentThread.Priority = ThreadPriority.Highest;
        double[] rates = new double[chunks];
        ulong acc = (ulong)(cpu + 1);
        const int n = 20000;
        Stopwatch sw = Stopwatch.StartNew();
        while (sw.ElapsedMilliseconds < warmupMs) acc += Block(acc, n);
        for (int k = 0; k < chunks; k++) {
            long blocks = 0;
            Stopwatch cs = Stopwatch.StartNew();
            while (cs.ElapsedMilliseconds < chunkMs) { acc += Block(acc, n); blocks++; }
            rates[k] = blocks * (double)n / cs.Elapsed.TotalSeconds / 1e6;
        }
        Sink ^= acc;
        Thread.EndThreadAffinity();
        return rates;
    }

    public static double[] Run(int cpu, int warmupMs, int chunks, int chunkMs) {
        double[] rates = null;
        Thread t = new Thread(() => { rates = Worker(cpu, warmupMs, chunks, chunkMs); });
        t.Start();
        t.Join();
        return rates;
    }

    // Sum over all CPUs of each CPU's median chunk rate
    public static double RunAll(int[] cpus, int warmupMs, int chunks, int chunkMs) {
        double[] medians = new double[cpus.Length];
        Thread[] threads = new Thread[cpus.Length];
        for (int i = 0; i < cpus.Length; i++) {
            int slot = i;
            threads[i] = new Thread(() => {
                double[] r = Worker(cpus[slot], warmupMs, chunks, chunkMs);
                Array.Sort(r);
                medians[slot] = r[r.Length / 2];
            });
        }
        foreach (Thread t in threads) t.Start();
        foreach (Thread t in threads) t.Join();
        double sum = 0;
        foreach (double m in medians) sum += m;
        return sum;
    }

    // Idle / boost-spike pattern on one CPU: bursts of 5-250 ms load with 30-1500 ms idle gaps.
    // Every burst recomputes a block with a known answer. Returns the number of wrong answers.
    public static int Burst(int cpu, int durationMs, int seed) {
        if (Expected != Expected2) return -1;   // the reference itself was computed wrong
        int errors = 0;
        Thread t = new Thread(() => {
            Pin(cpu);
            Random rnd = new Random(seed);
            Stopwatch total = Stopwatch.StartNew();
            while (total.ElapsedMilliseconds < durationMs) {
                int busy = rnd.Next(5, 250);
                Stopwatch b = Stopwatch.StartNew();
                while (b.ElapsedMilliseconds < busy) {
                    if (Block(CheckSeed, CheckN) != Expected) errors++;
                }
                Thread.Sleep(rnd.Next(30, 1500));
            }
            Thread.EndThreadAffinity();
        });
        t.Start();
        t.Join();
        return errors;
    }
}
'@

function Initialize-Bench {
    if (-not ('CtBench' -as [type])) { Add-Type -TypeDefinition $BenchSource }
}

# Raw counters per logical CPU. "% Processor Performance" comes from APERF/MPERF,
# so it shows the clock the core really ran at while busy (clock stretching included)
function Get-PerfSamples {
    $result = @{}
    foreach ($p in Get-CimInstance Win32_PerfRawData_Counters_ProcessorInformation) {
        if ($p.Name -match '^0,(\d+)$') { $result[[int]$Matches[1]] = $p }
    }
    return $result
}

function Get-EffMhz($Before, $After) {
    if (-not $Before -or -not $After) { return $null }
    $dBase = [double]$After.PercentProcessorPerformance_Base - [double]$Before.PercentProcessorPerformance_Base
    if ($dBase -le 0) { return $null }
    $pct = ([double]$After.PercentProcessorPerformance - [double]$Before.PercentProcessorPerformance) / $dBase
    return [double]$After.ProcessorFrequency * $pct / 100
}

function Get-Median([double[]] $Values) {
    $sorted = @($Values | Sort-Object)
    $n = $sorted.Count
    if ($n -eq 0) { return 0 }
    if ($n % 2) { return $sorted[($n - 1) / 2] }
    return ($sorted[$n / 2 - 1] + $sorted[$n / 2]) / 2
}

# Single-thread benchmark locked to the first thread of a core
function Measure-CorePerf([int] $Index) {
    Initialize-Bench
    $cpu   = (Get-CoreCpus $Index)[0]
    $s0    = Get-PerfSamples
    $rates = [CtBench]::Run($cpu, 1000, $Config.BenchSeconds, 1000)
    $s1    = Get-PerfSamples

    $mhz = Get-EffMhz $s0[$cpu] $s1[$cpu]
    if ($null -eq $mhz) { $mhz = 0 }
    [pscustomobject]@{
        effMHz = [int][Math]::Round($mhz)
        score  = [Math]::Round((Get-Median $rates), 1)
    }
}

# All threads at once
function Measure-AllCorePerf {
    Initialize-Bench
    $cpus  = @(0..((Get-LogicalCount) - 1))
    $s0    = Get-PerfSamples
    $total = [CtBench]::RunAll([int[]]$cpus, 2000, $Config.BenchSeconds, 1000)
    $s1    = Get-PerfSamples

    $clocks = @($cpus | ForEach-Object { Get-EffMhz $s0[$_] $s1[$_] } | Where-Object { $null -ne $_ })
    $avg = 0
    if ($clocks.Count -gt 0) { $avg = ($clocks | Measure-Object -Average).Average }
    [pscustomobject]@{
        effMHz = [int][Math]::Round($avg)
        score  = [Math]::Round($total, 1)
    }
}

# Returns the number of wrong answers (-1 = the reference itself was wrong)
function Invoke-Burst([int] $Cpu, [int] $Milliseconds) {
    Initialize-Bench
    return [CtBench]::Burst($Cpu, $Milliseconds, (Get-Random))
}
