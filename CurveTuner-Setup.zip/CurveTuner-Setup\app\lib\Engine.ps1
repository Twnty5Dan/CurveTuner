﻿# CurveTuner - the background engine: boot handling, crash resolution, commands, heartbeat, main loop.
# It runs as a SYSTEM task that starts with Windows, so it continues after a crash without anyone logging in.

$script:State     = $null
$script:LastTick  = Get-Date
$script:GapReason = ''

function New-TuningState([int[]] $Bios, $Cpu) {
    [pscustomobject]@{
        version        = 3
        phase          = 'selftest'    # selftest / search / combined / bios / done / error
        errorKind      = ''            # co-effect / setup (both retried after a restart) / crash
        cpu            = $Cpu          # what setup measured on this CPU (lib\Cpu.ps1)
        paused         = $false
        pauseReason    = ''
        bios           = @($Bios)      # BIOS values seen at the last boot
        biosAtStart    = @($Bios)
        lastBoot       = $null
        lastSeenUptimeMs = $null       # uptime at the last save: lower uptime at startup = the PC restarted
        current        = $null         # the test that is running right now (saved, so a crash can be blamed)
        crashTimes     = @()
        unexplainedCrashTimes = @()    # crashes that could not be blamed on a core
        idleCrashTimes = @()           # crashes while no test was running
        stateVersion   = 30
        combinedStage  = 0
        combinedRuns   = 0
        allCore        = $null
        alerts         = @()
        lastEventCheck = (Get-NowIso)
        startedAt      = (Get-NowIso)
        cores          = @(0..($(if ($Cpu) { [int]$Cpu.numCores } else { $Config.NumCores }) - 1) | ForEach-Object { New-CoreRecord $_ })
    }
}

# State files from older versions miss some fields
function Initialize-StateFields {
    $defaults = [ordered]@{ lastSeenUptimeMs = $null; unexplainedCrashTimes = @(); idleCrashTimes = @(); stateVersion = 30; errorKind = ''; cpu = $null }
    foreach ($name in $defaults.Keys) {
        if (-not ($script:State.PSObject.Properties.Name -contains $name)) {
            $script:State | Add-Member -NotePropertyName $name -NotePropertyValue $defaults[$name]
        }
    }
}

# The CPU profile from setup; a state from before version 3 gets it measured now
function Initialize-Cpu {
    if (-not $script:State.cpu) {
        $script:State.cpu = Get-CpuProfile
        Write-Log ('CPU measured: {0}, {1} cores, {2} threads, CO down to {3}' -f $script:State.cpu.name, $script:State.cpu.numCores, $script:State.cpu.logicalCount, $script:State.cpu.minValue)
    }
    Initialize-CpuConfig $script:State.cpu
}
function Save-State {
    Initialize-StateFields
    $script:State.lastSeenUptimeMs = Get-UptimeMs
    Write-JsonFile $StateFile $script:State
}

# Adds a time to a list in the state and returns how many of them are within the last $Minutes
function Add-RecentTime([string] $Field, [int] $Minutes) {
    $list = @(@($script:State.$Field) + (Get-NowIso) | Select-Object -Last 10)
    $script:State.$Field = $list
    return @($list | Where-Object { ((Get-Date) - (ConvertFrom-Iso $_)).TotalMinutes -lt $Minutes }).Count
}
function Read-State { Read-JsonFile $StateFile }

function Add-Alert([string] $Text, [string] $Level = 'info') {
    $script:State.alerts = @($script:State.alerts) + [pscustomobject]@{ time = (Get-NowIso); level = $Level; text = $Text }
    Write-History ("[{0}] {1}" -f $Level.ToUpperInvariant(), $Text)
}

function Set-Paused([string] $Reason) {
    $script:State.paused      = $true
    $script:State.pauseReason = $Reason
    Write-History "Paused: $Reason"
}

# Heartbeat for the dashboard. The last heartbeat before a freeze also tells when it happened.
function Update-Status([string] $Activity, $Elapsed = $null, $Total = $null, $ActiveCore = $null) {
    $cur = $script:State.current
    $status = [pscustomobject]@{
        time       = (Get-NowIso)
        pid        = $PID
        phase      = $script:State.phase
        paused     = $script:State.paused
        activity   = $Activity
        core       = $(if ($cur) { $cur.core } else { $null })
        value      = $(if ($cur) { $cur.value } else { $null })
        stageName  = $(if ($cur) { $cur.stageName } else { '' })
        elapsed    = $Elapsed
        total      = $Total
        activeCore = $ActiveCore
    }
    try { Write-JsonFile $StatusFile $status } catch { }
}

# Commands from the dashboard: pause / resume
function Read-Command {
    if (-not (Test-Path -LiteralPath $CommandFile)) { return $null }
    $cmd = ''
    try {
        $cmd = ([IO.File]::ReadAllText($CommandFile)).Trim().ToLowerInvariant()
        Remove-Item -LiteralPath $CommandFile -Force
    }
    catch { return $null }
    if ($cmd -notin @('pause', 'resume')) { return $null }
    Write-Log "Command: $cmd"
    return $cmd
}

function Use-EngineCommand([string] $Cmd) {
    if ($Cmd -eq 'pause' -and -not $script:State.paused) { Set-Paused 'paused by you'; Save-State }
    if ($Cmd -eq 'resume' -and $script:State.paused) {
        $script:State.paused      = $false
        $script:State.pauseReason = ''
        $script:State.crashTimes  = @()
        if ([int]$script:State.combinedRuns -ge $Config.MaxCombinedRuns) { $script:State.combinedRuns = 0 }   # you asked for more tries
        Write-History 'Resumed'
        Save-State
    }
}

# Called about every second while a test runs. Returns 'abort' to stop the test.
$script:OnTick = {
    param($Elapsed, $Total, $ActiveCore)

    $now = Get-Date
    if (($now - $script:LastTick).TotalSeconds -gt 30) {
        # The PC was asleep or hibernated: the temporary values may be gone, so this test does not count
        $script:GapReason = 'the PC was asleep'
        $script:LastTick  = $now
        return 'abort'
    }
    $script:LastTick = $now

    $cur = $script:State.current
    if ($cur -and $null -ne $ActiveCore -and $cur.activeCore -ne $ActiveCore) {
        $cur.activeCore = $ActiveCore
        Save-State
    }
    Update-Status 'testing' $Elapsed $Total $ActiveCore

    $cmd = Read-Command
    if ($cmd) {
        Use-EngineCommand $cmd
        if ($script:State.paused) { return 'abort' }
    }
    return $null
}

function Set-Current([string] $Kind, [int] $Core, $Value, [string] $Profile, [string] $StageName) {
    $script:State.current = [pscustomobject]@{
        kind       = $Kind          # core / ab / combined / burst / allcore / selftest
        core       = $Core
        value      = $Value
        profile    = $Profile
        stageName  = $StageName
        started    = (Get-NowIso)
        activeCore = $(if ($Core -ge 0) { $Core } else { $null })
    }
    Save-State
}

# End of a test unit. Every unit checks WHEA errors for its own time window,
# so from here on only idle time is left to check.
function Clear-Current {
    $script:State.current        = $null
    $script:State.lastEventCheck = Get-NowIso
    Save-State
}

# The values every core should have when nothing is being tested
function Get-SafeValues {
    $vals = @()
    for ($i = 0; $i -lt $Config.NumCores; $i++) {
        $vals += Get-SafeValue $script:State.cores[$i] ([int]$script:State.bios[$i])
    }
    return ,$vals
}

function Set-SafeValues {
    $safe = Get-SafeValues
    $change = @{}
    for ($i = 0; $i -lt $Config.NumCores; $i++) {
        if ($null -eq $script:Applied -or $script:Applied[$i] -ne $safe[$i]) { $change[$i] = $safe[$i] }
    }
    if ($change.Count -gt 0) { Set-CoOffsets $change }
}

# A new boot with a test still marked as running: find out what happened and who to blame
function Resolve-Crash {
    $cur     = $script:State.current
    $started = ConvertFrom-Iso $cur.started
    $whea    = @(Get-WheaErrors -Since $started | Where-Object { $null -ne $_.Core })
    $crashes = @(Get-CrashEvents -Since $started)

    $when = ''
    $beat = Read-JsonFile $StatusFile
    if ($beat -and $beat.time) { $when = ' at about ' + (ConvertFrom-Iso $beat.time).ToString('HH:mm') }

    if ($crashes.Count -eq 0 -and $whea.Count -eq 0) {
        Write-History ("Windows restarted normally during {0}, it will be repeated" -f $cur.stageName)
        Resolve-Interrupted 'normal restart'
        return
    }

    [void](Add-RecentTime 'crashTimes' 60)
    $unexplained = $false

    $wheaCores = @($whea | ForEach-Object { [int]$_.Core } | Sort-Object -Unique)
    $blame = @()
    if ($wheaCores.Count -gt 0) { $blame = $wheaCores }
    elseif ($null -ne $cur.activeCore) { $blame = @([int]$cur.activeCore) }
    $what = "crash$when during $($cur.stageName)"
    if ($wheaCores.Count -gt 0) { $what += ' (WHEA, APIC ID ' + (($whea | ForEach-Object { $_.Apic } | Sort-Object -Unique) -join '/') + ')' }

    switch ($cur.kind) {
        { $_ -in 'core', 'ab' } {
            $c = $script:State.cores[[int]$cur.core]
            if ($blame.Count -eq 0 -or $blame -contains [int]$cur.core) {
                $profile = $cur.profile
                if ($cur.kind -eq 'ab') { $profile = 'quick' }
                Complete-Test $c ([int]$cur.value) $profile 'FAIL' $what
                Write-History ("Core {0}: {1} FAILED - {2}" -f $cur.core, (Format-Short $cur.value), $what)
            }
            else {
                Add-CoreHistory $c 'quick' ([int]$cur.value) 'INTERRUPTED' "crash blamed on another core"
            }
            foreach ($b in ($blame | Where-Object { $_ -ne [int]$cur.core })) {
                $o = $script:State.cores[$b]
                $v = Get-SafeValue $o ([int]$script:State.bios[$b])
                Add-CoreHistory $o 'baseline' $v 'FAIL' "WHEA error at its normal value: $what"
                Add-Alert ("Core {0} caused a crash at its normal value {1}. It now gets {2} at every boot." -f $b, (Format-Short $v), (Format-Short (Get-SafeValue $o ([int]$script:State.bios[$b])))) 'warning'
            }
        }
        { $_ -in 'combined', 'burst', 'allcore' } {
            if ($blame.Count -gt 0) {
                foreach ($b in $blame) {
                    Set-CombinedFail $script:State.cores[$b] $what
                    Write-History ("Core {0}: final value failed ({1}), now {2}" -f $b, $what, (Format-Short $script:State.cores[$b].final))
                }
                $script:State.combinedStage = 0
                $script:State.combinedRuns++
            }
            else {
                Add-Alert "The PC crashed during $($cur.stageName) and Windows did not say which core. That part runs again." 'warning'
                $unexplained = $true
            }
        }
        'selftest' {
            $script:State.phase     = 'error'
            $script:State.errorKind = 'crash'
            Add-Alert "The PC crashed during the self-test, at your normal BIOS values. Fix that first (the BIOS values may be unstable)." 'error'
        }
    }

    # Crash-loop protection. A crash that was blamed on a core is progress (that value is now known to fail),
    # so only crashes that could not be blamed on anything count.
    if ($unexplained -and (Add-RecentTime 'unexplainedCrashTimes' 120) -ge 3) {
        Set-Paused '3 crashes that could not be blamed on a core'
        Add-Alert 'Paused after 3 crashes within 2 hours that could not be blamed on a core. Open CurveTuner and press R to continue.' 'warning'
    }

    $script:State.current        = $null
    $script:State.lastEventCheck = Get-NowIso
    Save-State
}

# A new boot without a running test: did the PC crash while idle (between tests, while paused, at the PIN screen)?
function Resolve-IdleCrash([datetime] $Since) {
    $crashes = @(Get-CrashEvents -Since $Since)
    if ($crashes.Count -eq 0) { return }

    $whea  = @(Get-WheaErrors -Since $Since | Where-Object { $null -ne $_.Core })
    $cores = @($whea | ForEach-Object { [int]$_.Core } | Sort-Object -Unique)
    foreach ($b in $cores) {
        $o = $script:State.cores[$b]
        $v = Get-SafeValue $o ([int]$script:State.bios[$b])
        Add-CoreHistory $o 'baseline' $v 'FAIL' 'crash while no test was running'
        Add-Alert ("The PC crashed while no test was running and Windows blamed core {0} (at {1}). It gets {2} at every boot from now on." -f $b, (Format-Short $v), (Format-Short (Get-SafeValue $o ([int]$script:State.bios[$b])))) 'warning'
    }
    if ($cores.Count -eq 0) {
        Add-Alert 'The PC restarted unexpectedly while no test was running, and Windows did not name a core.' 'info'
    }

    if ($script:State.phase -in 'selftest', 'search', 'combined' -and (Add-RecentTime 'idleCrashTimes' 60) -ge 3) {
        Set-Paused '3 crashes within an hour while no test was running'
        Add-Alert 'Paused: the PC crashed 3 times within an hour while no test was running. A BIOS value may be unstable at idle. Ask for help with history.log.' 'warning'
    }
    $script:State.lastEventCheck = Get-NowIso
}

# WHEA errors between tests (idle, light use): the core was at its safe value, so that value is the problem
function Test-IdleWhea {
    $since = ConvertFrom-Iso $script:State.lastEventCheck
    $whea  = @(Get-WheaErrors -Since $since | Where-Object { $null -ne $_.Core })
    $script:State.lastEventCheck = Get-NowIso
    foreach ($b in @($whea | ForEach-Object { [int]$_.Core } | Sort-Object -Unique)) {
        $o = $script:State.cores[$b]
        $v = Get-SafeValue $o ([int]$script:State.bios[$b])
        Add-CoreHistory $o 'baseline' $v 'FAIL' 'WHEA error while no test was running'
        Add-Alert ("Core {0} had a WHEA error while no test was running (at {1}). It gets {2} from now on." -f $b, (Format-Short $v), (Format-Short (Get-SafeValue $o ([int]$script:State.bios[$b])))) 'warning'
    }
    if ($whea.Count -gt 0) { Set-SafeValues }
    Save-State
}

# A test stopped without a crash (pause, restart of CurveTuner, normal reboot): it will be repeated
function Resolve-Interrupted([string] $Reason) {
    $cur = $script:State.current
    if (-not $cur) { return }
    if ($cur.kind -in 'core', 'ab') {
        $profile = $cur.profile
        if ($cur.kind -eq 'ab') { $profile = 'quick' }
        Add-CoreHistory $script:State.cores[[int]$cur.core] $profile ([int]$cur.value) 'INTERRUPTED' $Reason
    }
    Write-Log ("Interrupted ({0}): {1}" -f $Reason, $cur.stageName)
    $script:State.current        = $null
    $script:State.lastEventCheck = Get-NowIso
    Save-State
}

function Read-OffsetsWithRetry {
    $deadline = (Get-Date).AddSeconds(90)
    while ($true) {
        try { return ,(Get-CoOffsets) }
        catch {
            if ((Get-Date) -gt $deadline) { throw }
            Start-Sleep -Seconds 5    # right after boot the driver may need a moment
        }
    }
}

function Invoke-StartupChecks {
    $boot     = Get-LastBoot
    $lastSeen = $null
    if ($script:State.PSObject.Properties.Name -contains 'lastSeenUptimeMs') { $lastSeen = $script:State.lastSeenUptimeMs }
    # Rebooted when the uptime went down, or when Windows reports a different boot time
    $newBoot  = ($null -eq $lastSeen) -or ((Get-UptimeMs) -lt [double]$lastSeen)
    if (-not $newBoot -and $script:State.lastBoot) {
        $newBoot = [Math]::Abs(((ConvertFrom-Iso $script:State.lastBoot) - $boot).TotalSeconds) -gt 120
    }
    $hadBootBefore = [bool]$script:State.lastBoot
    $script:State.lastBoot = $boot.ToString('o')
    $offsets  = Read-OffsetsWithRetry

    if ($newBoot) {
        Write-Log ('New boot at ' + $boot.ToString('yyyy-MM-dd HH:mm:ss') + ', values: ' + ($offsets -join ','))

        $changed = @(0..($Config.NumCores - 1) | Where-Object { [int]$script:State.bios[$_] -ne $offsets[$_] })
        if ($changed.Count -gt 0 -and $script:State.phase -ne 'bios') {
            Add-Alert ('BIOS values changed on core(s) ' + ($changed -join ', ') + '. CurveTuner now uses them as the normal values.') 'info'
        }
        $script:State.bios = @($offsets)

        # A self-test that stopped because of the BIOS (PBO off) or CoreCycler runs again after every restart
        if ($script:State.phase -eq 'error' -and $script:State.errorKind -in 'co-effect', 'setup') {
            $script:State.phase     = 'selftest'
            $script:State.errorKind = ''
            Add-Alert 'Restarted: running the self-test again.' 'info'
        }
        if ($script:State.current) { Resolve-Crash }
        elseif ($hadBootBefore -and $script:State.phase -ne 'done') { Resolve-IdleCrash (ConvertFrom-Iso $script:State.lastEventCheck) }
        if ($script:State.phase -eq 'bios') { Test-BiosEntry }
        if ($script:State.phase -eq 'done') { [void](Invoke-Watch) }
    }
    elseif ($script:State.current) {
        Resolve-Interrupted 'CurveTuner was restarted'
    }

    Set-SafeValues
    Save-State
}

function Invoke-MainLoop {
    $lastBeat      = [datetime]::MinValue
    $lastIdleCheck = Get-Date
    while ($true) {
        $now = Get-Date
        if (($now - $script:LastTick).TotalSeconds -gt 30) {
            # Woke up from sleep or hibernation: the temporary values are gone, put the safe ones back
            Write-Log 'Resumed from sleep/hibernation'
            [void](Get-CoOffsets)
            Set-SafeValues
        }
        $script:LastTick = $now

        $cmd = Read-Command
        if ($cmd) { Use-EngineCommand $cmd }

        if ($script:State.phase -in 'bios', 'done', 'error') {
            Update-Status $script:State.phase
            return
        }
        if ($script:State.paused) {
            if (($now - $lastBeat).TotalSeconds -ge 2) { Update-Status 'paused'; $lastBeat = $now }
            if (($now - $lastIdleCheck).TotalSeconds -ge 60) { Test-IdleWhea; $lastIdleCheck = $now }
            Start-Sleep -Milliseconds 500
            continue
        }

        $uptime = Get-UptimeSec
        if ($uptime -lt $Config.BootSettleSec) {
            Update-Status ('waiting for Windows to settle ({0} s)' -f [int]($Config.BootSettleSec - $uptime))
            if (($now - $lastIdleCheck).TotalSeconds -ge 60) { Test-IdleWhea; $lastIdleCheck = $now }
            Start-Sleep -Seconds 1
            continue
        }

        # WHEA errors since the last test (idle time) belong to the cores' safe values
        Test-IdleWhea
        $lastIdleCheck = Get-Date

        switch ($script:State.phase) {
            'selftest' { Invoke-SelfTest }
            'search'   { Invoke-SearchStep }
            'combined' { Invoke-CombinedStep }
        }
    }
}

function Set-NoSleep {
    if (-not ('CurveTuner.Power' -as [type])) {
        Add-Type -Namespace CurveTuner -Name Power -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint esFlags);'
    }
    # ES_CONTINUOUS | ES_SYSTEM_REQUIRED: no sleep while tuning, also at the login screen
    [void][CurveTuner.Power]::SetThreadExecutionState([uint32]2147483649)
}

function Start-Engine {
    $mutex = New-Object Threading.Mutex($false, 'Global\CurveTunerEngine')
    if (-not $mutex.WaitOne(0)) { return }   # already running
    try {
        $script:State = Read-State
        if (-not $script:State) { Write-Log 'Engine: no state, nothing to do'; return }
        Initialize-StateFields
        Write-Log "Engine started (pid $PID, version $Version, phase $($script:State.phase))"

        $script:CcDir = Find-CoreCycler
        Initialize-Cpu
        [void](Test-Prerequisites)   # also puts the 64-bit .NET first for CoreCycler
        Set-NoSleep
        Stop-TestPrograms
        Invoke-StartupChecks
        Invoke-MainLoop
    }
    catch {
        Write-Log ('ENGINE ERROR: ' + $_.Exception.Message + ' | ' + $_.ScriptStackTrace)
        try {
            Stop-TestPrograms
            if ($script:State) {
                Resolve-Interrupted 'CurveTuner error'
                Set-Paused ('error: ' + $_.Exception.Message)
                Add-Alert ('CurveTuner stopped because of an error: ' + $_.Exception.Message) 'error'
                Save-State
                Set-SafeValues
            }
        }
        catch { }
    }
    finally {
        $mutex.ReleaseMutex()
        $mutex.Dispose()
    }
}
