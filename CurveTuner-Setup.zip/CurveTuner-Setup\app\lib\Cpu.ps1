﻿# CurveTuner - which Ryzen this is: generation, Curve Optimizer range, cores and threads, the APIC ID of every
# logical CPU (to turn a WHEA error into a core number) and the board (for the BIOS menu path).
# Measured once at setup and stored in the state ("cpu"), so the SYSTEM engine never has to guess.

$script:ApicToCore = @{}   # APIC ID -> core
$script:CoreCpus   = @()   # core -> its logical CPUs
$script:CpuProfile = $null

# Generation from the CPUID family / model in Win32_Processor.Caption ("AMD64 Family 25 Model 33 Stepping 2")
# Returns @{ Name; Family; Model; Generation; MinValue; CoarseStep; Problem } - Problem is $null when supported.
function Get-CpuIdentity($Cpu, [int[]] $ChassisTypes) {
    $name = ([string]$Cpu.Name).Trim()
    $family = 0; $model = 0
    if ([string]$Cpu.Caption -match 'Family\s+(\d+)\s+Model\s+(\d+)') { $family = [int]$Matches[1]; $model = [int]$Matches[2] }
    $id = [ordered]@{ Name = $name; Family = $family; Model = $model; Generation = ''; MinValue = -30; CoarseStep = 3; Problem = $null }

    if ([string]$Cpu.Manufacturer -ne 'AuthenticAMD' -or $name -notmatch 'Ryzen') {
        $id.Problem = "CurveTuner is for AMD Ryzen CPUs (this PC has: $name)."
        return [pscustomobject]$id
    }
    if ($family -eq 25 -and $model -lt 0x60) { $id.Generation = 'Zen 3' }
    elseif ($family -eq 25) { $id.Generation = 'Zen 4'; $id.MinValue = -50; $id.CoarseStep = 5 }
    elseif ($family -eq 26) { $id.Generation = 'Zen 5'; $id.MinValue = -50; $id.CoarseStep = 5 }
    else {
        $id.Problem = "The $name has no Curve Optimizer (it came with Ryzen 5000). CurveTuner needs Ryzen 5000, 7000, 8000G or 9000."
        return [pscustomobject]$id
    }
    if ($name -match 'Threadripper|EPYC') {
        $id.Problem = "CurveTuner is made for desktop Ryzen CPUs, not $name."
    }
    elseif ($name -match '5[5-8]00X3D') {
        $id.Problem = "Curve Optimizer is locked on the $name on most boards, so CurveTuner cannot tune it."
    }
    elseif (@($ChassisTypes | Where-Object { $_ -in 8, 9, 10, 11, 12, 14, 18, 21, 30, 31, 32 }).Count -gt 0) {
        $id.Problem = 'This is a laptop. Its BIOS has no per-core Curve Optimizer, so the result could not be kept.'
    }
    return [pscustomobject]$id
}

# Parses the output of CoreCycler's APICID.exe: "Logical CPU 12 - Physical Core 6 - APIC ID 16 - SMT On"
function ConvertFrom-ApicIdOutput([string[]] $Lines) {
    $rows = @()
    foreach ($l in $Lines) {
        if ($l -match 'Logical CPU\s+(\d+)\s*-\s*Physical Core\s+(\d+)\s*-\s*APIC ID\s+(\d+)') {
            $rows += [pscustomobject]@{ Cpu = [int]$Matches[1]; Core = [int]$Matches[2]; Apic = [int]$Matches[3] }
        }
    }
    if ($rows.Count -eq 0) { throw 'APICID.exe gave no usable output' }
    $cores = @($rows | ForEach-Object { $_.Core } | Sort-Object -Unique)
    if ($cores[0] -ne 0 -or $cores[-1] -ne $cores.Count - 1) { throw ('APICID.exe reports unexpected core numbers: ' + ($cores -join ',')) }
    $apicMap = [ordered]@{}
    foreach ($r in $rows) { $apicMap[[string]$r.Apic] = $r.Core }
    $coreCpus = @(foreach ($c in $cores) { , @($rows | Where-Object { $_.Core -eq $c } | Sort-Object Cpu | ForEach-Object { $_.Cpu }) })
    return [pscustomobject]@{
        numCores       = $cores.Count
        logicalCount   = $rows.Count
        threadsPerCore = [int][Math]::Round($rows.Count / $cores.Count)
        apicToCore     = [pscustomobject]$apicMap
        coreCpus       = $coreCpus
    }
}

function Get-ApicMap {
    $exe = Get-ChildItem -LiteralPath (Join-Path $CcDir 'tools') -Filter 'APICID.exe' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $exe) { throw 'APICID.exe was not found in CoreCycler''s tools folder' }
    $out = @(& $exe.FullName 2>&1 | ForEach-Object { [string]$_ })
    return (ConvertFrom-ApicIdOutput $out)
}

# Where Curve Optimizer is in the BIOS of this board maker
function Get-BiosHint([string] $Vendor) {
    switch -Regex ($Vendor) {
        'ASUS'     { return @{ Key = 'Del at boot, then F7 (Advanced Mode)'; Path = 'Advanced  >  AMD Overclocking  >  Precision Boost Overdrive  >  Curve Optimizer'; Alt = 'on some ASUS boards also under Ai Tweaker / Extreme Tweaker  >  Precision Boost Overdrive' } }
        'Micro-Star|MSI' { return @{ Key = 'Del at boot, then F7 (Advanced)'; Path = 'OC  >  Advanced CPU Configuration  >  AMD Overclocking  >  Precision Boost Overdrive  >  Curve Optimizer'; Alt = '' } }
        'Gigabyte' { return @{ Key = 'Del at boot, then F2 (Advanced Mode)'; Path = 'Tweaker  >  Advanced CPU Settings  >  Precision Boost Overdrive  >  Curve Optimizer'; Alt = 'or Settings  >  AMD Overclocking  >  Precision Boost Overdrive' } }
        'ASRock'   { return @{ Key = 'F2 or Del at boot'; Path = 'Advanced  >  AMD Overclocking  >  Precision Boost Overdrive  >  Curve Optimizer'; Alt = 'or OC Tweaker  >  Precision Boost Overdrive' } }
    }
    return @{ Key = 'Del or F2 at boot'; Path = 'AMD Overclocking  >  Precision Boost Overdrive  >  Curve Optimizer'; Alt = 'the menu is usually under Advanced, Tweaker or OC' }
}

# Everything about this CPU in one object (stored in the state)
function Get-CpuProfile {
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $chassis = @((Get-CimInstance Win32_SystemEnclosure -ErrorAction SilentlyContinue).ChassisTypes)
    $id = Get-CpuIdentity $cpu $chassis
    $board = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue | Select-Object -First 1
    $vendor = ([string]$board.Manufacturer).Trim()
    $prof = [ordered]@{
        name = $id.Name; family = $id.Family; model = $id.Model; generation = $id.Generation
        minValue = $id.MinValue; coarseStep = $id.CoarseStep; problem = $id.Problem
        boardVendor = $vendor; boardName = ([string]$board.Product).Trim()
        numCores = [int]$cpu.NumberOfCores; logicalCount = [int]$cpu.NumberOfLogicalProcessors; threadsPerCore = 1
        apicToCore = $null; coreCpus = @()
    }
    if (-not $id.Problem) {
        if ($prof.logicalCount -gt 64) { $prof.problem = 'More than 64 threads is not supported.' }
        else {
            $map = Get-ApicMap
            $prof.numCores = $map.numCores; $prof.logicalCount = $map.logicalCount; $prof.threadsPerCore = $map.threadsPerCore
            $prof.apicToCore = $map.apicToCore; $prof.coreCpus = $map.coreCpus
        }
    }
    return [pscustomobject]$prof
}

# Puts this CPU's values into $Config and the lookup tables
function Initialize-CpuConfig($Cpu) {
    $script:CpuProfile = $Cpu
    $Config.NumCores   = [int]$Cpu.numCores
    $Config.MinValue   = [int]$Cpu.minValue
    $Config.CoarseStep = [int]$Cpu.coarseStep
    $script:ApicToCore = @{}
    if ($Cpu.apicToCore) {
        foreach ($p in $Cpu.apicToCore.PSObject.Properties) { $script:ApicToCore[[int]$p.Name] = [int]$p.Value }
    }
    $script:CoreCpus = @(foreach ($c in @($Cpu.coreCpus)) { , @($c | ForEach-Object { [int]$_ }) })
}

# The logical CPUs of a core (first = the one the benchmarks use)
function Get-CoreCpus([int] $Core) {
    if ($script:CoreCpus.Count -gt $Core) { return , @($script:CoreCpus[$Core]) }
    return , @(2 * $Core, 2 * $Core + 1)
}

function Get-LogicalCount {
    if ($script:CpuProfile -and $script:CpuProfile.logicalCount) { return [int]$script:CpuProfile.logicalCount }
    return [int](Get-CimInstance Win32_Processor | Select-Object -First 1).NumberOfLogicalProcessors
}

# "Ryzen 9 5900X" from "AMD Ryzen 9 5900X 12-Core Processor"
function Get-CpuShortName {
    if (-not $script:CpuProfile) { return 'Ryzen' }
    return (([string]$script:CpuProfile.name) -replace '^AMD\s+', '' -replace '\s+\d+-Core Processor\s*$', '' -replace '\s+w/.*$', '').Trim()
}
