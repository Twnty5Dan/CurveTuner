﻿<#
    CurveTuner setup - installs everything CurveTuner needs on this PC:
      - checks Windows and the CPU (AMD Ryzen 5000 / 7000 / 8000G / 9000 desktop)
      - .NET 8 Runtime x64, Visual C++ 2015-2022 x64 + x86, the PawnIO driver (official winget packages)
      - CoreCycler v0.11.0.3 with Prime95, y-cruncher and ryzen-smu-cli (official GitHub release, checked
        against its SHA-256), unpacked with Windows' tar or, if that cannot, 7-Zip (installed through winget)
      - CurveTuner itself in C:\CurveTuner, plus a "CurveTuner" shortcut on the desktop
    Run it with Setup.cmd. Nothing is changed on the CPU itself. -DryRun shows what would happen.
#>
[CmdletBinding()]
param([switch] $DryRun, [string] $InstallDir = 'C:\CurveTuner')

$ErrorActionPreference = 'Stop'
$Here = $PSScriptRoot

$CoreCyclerDl = @{
    Url    = 'https://github.com/sp00n/CoreCycler/releases/download/v0.11.0.3/CoreCycler-v0.11.0.3.7z'
    File   = 'CoreCycler-v0.11.0.3.7z'
    Sha256 = '721ED2948B51A2FC7C60289ECB7CBF62057B22D54C4BA5DC70AC5A107FCC1A63'
    Page   = 'https://github.com/sp00n/CoreCycler/releases'
}

function Say([string] $Text = '', [string] $Color = 'Gray') { Write-Host $Text -ForegroundColor $Color }
function Step([string] $Text) { Say ''; Say ('  ' + $Text) White }
function Ok([string] $Text) { Say ('    OK  ' + $Text) Green }
function Act([string] $Text) { if ($DryRun) { Say ('    (dry run) would ' + $Text) DarkYellow } else { Say ('    ' + $Text + '...') DarkGray } }
function Fail([string] $Text) { throw $Text }

function Test-Admin {
    ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

$script:Winget = $null
function Install-WingetPackage([string] $Id, [string] $What) {
    if (-not $script:Winget) {
        $script:Winget = Get-Command winget -ErrorAction SilentlyContinue
        if (-not $script:Winget) { Fail ("{0} is missing and winget (Windows package manager, from the Microsoft Store: ""App Installer"") is not available to install it." -f $What) }
    }
    Act ("install {0} with winget ({1})" -f $What, $Id)
    if ($DryRun) { return }
    & $script:Winget.Source install --id $Id -e --silent --accept-package-agreements --accept-source-agreements | Out-Host
}

function Test-DotNet8 {
    $exe = Join-Path $env:ProgramFiles 'dotnet\dotnet.exe'
    if (-not (Test-Path -LiteralPath $exe)) { return $false }
    return [bool](& $exe --list-runtimes 2>$null | Select-String -Pattern '^Microsoft\.NETCore\.App 8\.')
}

# Visual C++ 2015-2022 at least 14.29 ('x64' or 'x86'), the same check as CoreCycler
function Test-VcRedist([string] $Arch) {
    $keys = 'HKLM:\SOFTWARE\WoW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    foreach ($e in Get-ItemProperty -Path $keys -ErrorAction SilentlyContinue) {
        if ($e.DisplayName -notmatch '^Microsoft Visual C\+\+\D*(\d|-){4,9}.*(Redistributable|Minimum)') { continue }
        $ver = $null
        if (-not [version]::TryParse(([string]$e.DisplayVersion -replace '[^\d\.]', ''), [ref]$ver)) { continue }
        if ($ver.Major -lt 14 -or ($ver.Major -eq 14 -and $ver.Minor -lt 29)) { continue }
        $isX64 = $e.DisplayName -match 'x64'
        if (($Arch -eq 'x64') -eq $isX64) { return $true }
    }
    return $false
}

function Get-CheckedDownload($D, [string] $What) {
    $dir = Join-Path $env:TEMP ('CurveTunerSetup-' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
    New-Item -ItemType Directory -Force $dir | Out-Null
    $file = Join-Path $dir $D.File
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = 'SilentlyContinue'
    try { Invoke-WebRequest -UseBasicParsing -Uri $D.Url -OutFile $file -UserAgent 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) CurveTunerSetup' }
    catch { Fail ("Could not download {0} ({1}). Check the internet connection, or get it from {2}" -f $What, $_.Exception.Message, $D.Page) }
    $hash = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    if ($hash -ne $D.Sha256) { Fail ("The {0} download does not match the known file (SHA-256 {1}). Nothing was installed from it." -f $What, $hash) }
    Ok ("{0} downloaded and checked (SHA-256 matches)" -f $What)
    return $file
}

function Find-SevenZip {
    foreach ($p in @((Join-Path $env:ProgramFiles '7-Zip\7z.exe'), (Join-Path ${env:ProgramFiles(x86)} '7-Zip\7z.exe'))) { if (Test-Path -LiteralPath $p) { return $p } }
    return $null
}

# ---------------------------------------------------------------------------------------------------
if (-not $DryRun -and -not (Test-Admin)) {
    $args2 = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $MyInvocation.MyCommand.Path), '-InstallDir', ('"{0}"' -f $InstallDir))
    Start-Process -FilePath 'powershell.exe' -ArgumentList $args2 -Verb RunAs
    exit
}

try {
    $Host.UI.RawUI.WindowTitle = 'CurveTuner setup'
    Say '  ================================================================' DarkCyan
    Say '   CurveTuner setup' Cyan
    Say '  ================================================================' DarkCyan
    if ($DryRun) { Say '   DRY RUN: nothing is changed.' DarkYellow }

    # 1. Windows and the CPU
    Step '1. Checking Windows and the CPU'
    if (-not [Environment]::Is64BitOperatingSystem) { Fail 'CurveTuner needs 64-bit Windows 10 or 11.' }
    $os = Get-CimInstance Win32_OperatingSystem
    if ([version]$os.Version -lt [version]'10.0') { Fail 'CurveTuner needs Windows 10 or 11.' }
    Ok $os.Caption
    . (Join-Path $Here 'app\lib\Cpu.ps1')
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $chassis = @((Get-CimInstance Win32_SystemEnclosure -ErrorAction SilentlyContinue).ChassisTypes)
    $id = Get-CpuIdentity $cpu $chassis
    if ($id.Problem) { Fail $id.Problem }
    if ([int]$cpu.NumberOfLogicalProcessors -gt 64) { Fail 'More than 64 threads is not supported.' }
    Ok ('{0} ({1}, {2} cores, Curve Optimizer down to {3})' -f $id.Name, $id.Generation, $cpu.NumberOfCores, $id.MinValue)
    $board = Get-CimInstance Win32_BaseBoard -ErrorAction SilentlyContinue | Select-Object -First 1
    Ok ('board: {0} {1}' -f ([string]$board.Manufacturer).Trim(), ([string]$board.Product).Trim())

    # 2. What CoreCycler and ryzen-smu-cli need
    Step '2. Runtimes and the PawnIO driver'
    if (Test-DotNet8) { Ok '.NET 8 Runtime (x64)' } else { Install-WingetPackage 'Microsoft.DotNet.Runtime.8' '.NET 8 Runtime (x64)' }
    if (Test-VcRedist 'x64') { Ok 'Visual C++ 2015-2022 (x64)' } else { Install-WingetPackage 'Microsoft.VCRedist.2015+.x64' 'Visual C++ 2015-2022 (x64)' }
    if (Test-VcRedist 'x86') { Ok 'Visual C++ 2015-2022 (x86)' } else { Install-WingetPackage 'Microsoft.VCRedist.2015+.x86' 'Visual C++ 2015-2022 (x86)' }
    if (Get-Service -Name 'PawnIO' -ErrorAction SilentlyContinue) { Ok 'PawnIO driver' } else { Install-WingetPackage 'namazso.PawnIO' 'the PawnIO driver (lets ryzen-smu-cli read and set Curve Optimizer)' }
    if (-not $DryRun) {
        $missing = @()
        if (-not (Test-DotNet8)) { $missing += '.NET 8 Runtime (x64)' }
        if (-not (Test-VcRedist 'x64')) { $missing += 'Visual C++ (x64)' }
        if (-not (Test-VcRedist 'x86')) { $missing += 'Visual C++ (x86)' }
        if (-not (Get-Service -Name 'PawnIO' -ErrorAction SilentlyContinue)) { $missing += 'PawnIO' }
        if ($missing.Count) { Fail ('Still missing after installing: ' + ($missing -join ', ') + '. Restart the PC and run Setup again.') }
    }

    # 3. CoreCycler (Prime95, y-cruncher, ryzen-smu-cli, APICID)
    Step '3. CoreCycler (stress tests)'
    $ccRoot = Join-Path $InstallDir 'CoreCycler'
    $cc = Get-ChildItem -LiteralPath $ccRoot -Filter 'script-corecycler.ps1' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($cc) { Ok ('already there: ' + $cc.DirectoryName) }
    else {
        Act ('download CoreCycler v0.11.0.3 (45 MB) from GitHub and check it')
        if (-not $DryRun) {
            $arc = Get-CheckedDownload $CoreCyclerDl 'CoreCycler'
            New-Item -ItemType Directory -Force $ccRoot | Out-Null
            Act 'unpack it'
            & tar.exe -xf $arc -C $ccRoot 2>$null
            $cc = Get-ChildItem -LiteralPath $ccRoot -Filter 'script-corecycler.ps1' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            if (-not $cc) {
                # older Windows 10: its tar cannot open 7z files
                $sevenZip = Find-SevenZip
                if (-not $sevenZip) { Install-WingetPackage '7zip.7zip' '7-Zip (to unpack CoreCycler)'; $sevenZip = Find-SevenZip }
                if (-not $sevenZip) { Fail 'Could not unpack CoreCycler (no 7-Zip). Install 7-Zip and run Setup again.' }
                & $sevenZip x $arc ('-o' + $ccRoot) -y | Out-Null
                $cc = Get-ChildItem -LiteralPath $ccRoot -Filter 'script-corecycler.ps1' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
            }
            if (-not $cc) { Fail 'CoreCycler was unpacked but script-corecycler.ps1 is missing.' }
            Get-ChildItem -LiteralPath $ccRoot -Recurse -File | Unblock-File
            Ok ('CoreCycler unpacked: ' + $cc.DirectoryName)
        }
    }

    # 4. CurveTuner itself
    Step ('4. CurveTuner in ' + $InstallDir)
    $state = Join-Path $InstallDir 'data\state.json'
    $files = @('app\CurveTuner.exe', 'app\CurveTuner.ps1')
    if (Test-Path -LiteralPath $state) {
        # Installed and tuning: the running engine must not get new files under its feet. CurveTuner installs
        # them itself (key U in its window), which restarts the engine cleanly.
        $upd = 'C:\CurveTuner-update'
        Act ("put the new version in {0} (CurveTuner is already set up here: open it and press U to install it)" -f $upd)
        if (-not $DryRun) {
            New-Item -ItemType Directory -Force (Join-Path $upd 'lib') | Out-Null
            foreach ($f in $files) { Copy-Item -LiteralPath (Join-Path $Here $f) -Destination $upd -Force }
            Copy-Item -Path (Join-Path $Here 'app\lib\*.ps1') -Destination (Join-Path $upd 'lib') -Force
            Get-ChildItem -LiteralPath $upd -Recurse -File | Unblock-File
            Ok 'update is waiting: open CurveTuner and press U'
        }
    }
    else {
        Act ('copy the program files to ' + $InstallDir)
        if (-not $DryRun) {
            New-Item -ItemType Directory -Force (Join-Path $InstallDir 'lib') | Out-Null
            foreach ($f in $files) { Copy-Item -LiteralPath (Join-Path $Here $f) -Destination $InstallDir -Force }
            Copy-Item -Path (Join-Path $Here 'app\lib\*.ps1') -Destination (Join-Path $InstallDir 'lib') -Force
            Copy-Item -LiteralPath (Join-Path $Here 'README.txt') -Destination $InstallDir -Force
            Get-ChildItem -LiteralPath $InstallDir -File | Unblock-File
            Get-ChildItem -LiteralPath (Join-Path $InstallDir 'lib') -File | Unblock-File
            Ok 'program files copied'
        }
    }

    # 5. Shortcut
    Step '5. Desktop shortcut'
    $lnk = Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'CurveTuner.lnk'
    Act ('create ' + $lnk)
    if (-not $DryRun) {
        $sh = New-Object -ComObject WScript.Shell
        $l = $sh.CreateShortcut($lnk)
        $l.TargetPath = Join-Path $InstallDir 'CurveTuner.exe'
        $l.WorkingDirectory = $InstallDir
        $l.Description = 'Automatic per-core Curve Optimizer for AMD Ryzen'
        $l.Save()
        Ok 'shortcut "CurveTuner" is on the desktop'
    }

    $hint = Get-BiosHint ([string]$board.Manufacturer)
    Say ''
    Say '  ================================================================' DarkCyan
    if ($DryRun) { Say '   Dry run finished: nothing was changed.' Green } else { Say '   Setup finished.' Green }
    Say '  ================================================================' DarkCyan
    Say ''
    Say '  BEFORE starting CurveTuner, once in the BIOS (see README.txt):' White
    Say ('   {0}:  {1}' -f $hint.Key, $hint.Path)
    if ($hint.Alt) { Say ('   ({0})' -f $hint.Alt) DarkGray }
    Say '   Precision Boost Overdrive = Advanced,  PBO Limits = Auto,  Curve Optimizer = Per Core (all 0). Save with F10.'
    Say '   (Not "Enabled": on many boards that also lifts the power limits - too hot with a stock cooler.)' DarkGray
    Say '  CurveTuner checks this itself in its self-test.'
    Say ''
    if (-not $DryRun) {
        Write-Host '  Is that done and do you want to start CurveTuner now?  [Y] yes   [N] no (start it later from the desktop)   ' -ForegroundColor Cyan -NoNewline
        $k = [Console]::ReadKey($true).KeyChar.ToString().ToUpperInvariant()
        Write-Host " $k"
        if ($k -eq 'Y' -and -not (Test-Path -LiteralPath $state)) { Start-Process -FilePath (Join-Path $InstallDir 'CurveTuner.exe') -WorkingDirectory $InstallDir }
    }
}
catch {
    Say ''
    Say ('  SETUP STOPPED: ' + $_.Exception.Message) Red
    Say ''
    if (-not $DryRun) { Read-Host '  Press Enter to close' | Out-Null }
    exit 1
}
if (-not $DryRun) { Read-Host '  Press Enter to close' | Out-Null }
