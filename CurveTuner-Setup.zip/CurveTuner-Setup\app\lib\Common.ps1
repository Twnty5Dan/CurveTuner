# CurveTuner - shared settings, paths and small helpers
# Dot-sourced by CurveTuner.ps1, which sets $Root before loading this file.

$Version   = '3.0'
$UpdateDir = 'C:\CurveTuner-update'   # a new version waiting here is installed with U in the dashboard

# Values marked "per CPU" are set by Initialize-CpuConfig (lib\Cpu.ps1) from what setup measured on this CPU
$Config = @{
    NumCores            = 0       # per CPU: enabled cores
    MinValue            = -30     # per CPU: most negative Curve Optimizer value (-30 Ryzen 5000, -50 Ryzen 7000 and newer)
    MaxValue            = 10      # highest positive value ever used for a weak core
    CoarseStep          = 3       # per CPU: search steps until the first fail, then steps of 1 (5 on the wider -50 range)
    EffectStep          = 10      # self-test: all cores this much LESS negative (= more voltage, safe) ...
    EffectMinPct        = 0.7     # ... must lower the all-core clock by at least this much, or PBO is off
    SafetyMargin        = 2       # final value = confirmed limit + this (less negative)
    BootSettleSec       = 180     # no testing in the first 3 minutes after boot (early crashes count as failed boots)
    StretchPct          = 1.5     # A/B: clock AND score this much below the BIOS value = clock stretching
    BenchSeconds        = 6       # measured seconds per benchmark
    BenchCooldownSec    = 15      # idle time before the A/B benchmark
    BurstMinutesPerCore = 2       # idle/boost-spike test per core in the final validation
    MaxCombinedRuns     = 4       # give up (and pause) after this many failed final validations
    TimeoutExtraMin     = 15      # a CoreCycler run is treated as hung after its runtime plus this
    EngineTask          = 'CurveTuner Engine'
    ViewTask            = 'CurveTuner View'
    LegacyTask          = 'CurveTuner'    # logon task of the old BIOS-only version
}

# Every stage is one CoreCycler run
$Profiles = @{
    selftest = @(
        @{ Name = 'Prime95 SSE Huge (self-test)'; Program = 'PRIME95'; Minutes = 1; Threads = 1; Section = 'Prime95'; Options = [ordered]@{ mode = 'SSE'; FFTSize = 'Huge' } }
    )
    quick = @(
        @{ Name = 'y-cruncher N63+VT3'; Program = 'YCRUNCHER'; Minutes = 3; Threads = 2; Section = 'yCruncher'; Options = [ordered]@{ mode = '19-ZN2 ~ Kagari'; tests = 'N63, VT3' } },
        @{ Name = 'Prime95 SSE Huge';   Program = 'PRIME95';   Minutes = 3; Threads = 1; Section = 'Prime95';   Options = [ordered]@{ mode = 'SSE'; FFTSize = 'Huge' } }
    )
    confirm = @(
        @{ Name = 'Prime95 SSE Huge';     Program = 'PRIME95';   Minutes = 8; Threads = 1; Section = 'Prime95';   Options = [ordered]@{ mode = 'SSE'; FFTSize = 'Huge' } },
        @{ Name = 'y-cruncher N63+VT3';   Program = 'YCRUNCHER'; Minutes = 8; Threads = 2; Section = 'yCruncher'; Options = [ordered]@{ mode = '19-ZN2 ~ Kagari'; tests = 'N63, VT3' } },
        @{ Name = 'Prime95 SSE Smallest'; Program = 'PRIME95';   Minutes = 4; Threads = 1; Section = 'Prime95';   Options = [ordered]@{ mode = 'SSE'; FFTSize = 'Smallest' } }
    )
    # Final validation: all cores at their final values, CoreCycler cycles through every core
    combined = @(
        @{ Name = 'Prime95 SSE Huge, all cores';   Program = 'PRIME95';   Minutes = 3; Threads = 1; Section = 'Prime95';   Options = [ordered]@{ mode = 'SSE'; FFTSize = 'Huge' } },
        @{ Name = 'y-cruncher N63+VT3, all cores'; Program = 'YCRUNCHER'; Minutes = 3; Threads = 2; Section = 'yCruncher'; Options = [ordered]@{ mode = '19-ZN2 ~ Kagari'; tests = 'N63, VT3' } }
    )
}

$DataDir     = Join-Path $Root 'data'
$ControlDir  = Join-Path $DataDir 'control'
$StateFile   = Join-Path $DataDir 'state.json'
$StatusFile  = Join-Path $DataDir 'status.json'
$HistoryFile = Join-Path $DataDir 'history.log'
$EngineLog   = Join-Path $DataDir 'engine.log'
$CommandFile = Join-Path $ControlDir 'command.txt'
$BiosFile    = Join-Path $Root 'BIOS-values.txt'


function Say([string] $Text = '', [string] $Color = 'Gray') {
    Write-Host $Text -ForegroundColor $Color
}

function Get-NowIso { (Get-Date).ToString('o') }

# Version of the update waiting in $UpdateDir, or $null
function Get-UpdateVersion {
    $f = Join-Path $UpdateDir 'lib\Common.ps1'
    if (-not (Test-Path -LiteralPath $f)) { return $null }
    $m = Select-String -LiteralPath $f -Pattern "^\`$Version\s*=\s*'([^']+)'" | Select-Object -First 1
    if ($m) { return $m.Matches[0].Groups[1].Value }
    return $null
}

function ConvertFrom-Iso([string] $Text) {
    [datetime]::Parse($Text, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind)
}

function Get-LastBoot { (Get-CimInstance Win32_OperatingSystem).LastBootUpTime }

# Milliseconds since Windows started. Restarts at 0 on every boot and ignores clock changes,
# so "uptime went down" is a reliable sign of a reboot.
function Get-UptimeMs {
    if (-not ('CurveTuner.Native' -as [type])) {
        Add-Type -Namespace CurveTuner -Name Native -MemberDefinition '[DllImport("kernel32.dll")] public static extern ulong GetTickCount64();'
    }
    return [double][CurveTuner.Native]::GetTickCount64()
}

function Get-UptimeSec { (Get-UptimeMs) / 1000 }

function Test-Admin {
    ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# -17 / +3 / 0
function Format-Short($Value) {
    if ($null -eq $Value) { return '-' }
    $v = [int]$Value
    if ($v -gt 0) { return "+$v" }
    return "$v"
}

# The BIOS shows a sign and a magnitude per core
function Get-BiosSign([int] $Value) { if ($Value -gt 0) { 'Positive' } else { 'Negative' } }

function Write-Log([string] $Text) {
    try {
        $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
        Add-Content -LiteralPath $EngineLog -Value $line -Encoding UTF8
    }
    catch { }
}

# Human-readable log, shown in the dashboard
function Write-History([string] $Text) {
    try {
        $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
        Add-Content -LiteralPath $HistoryFile -Value $line -Encoding UTF8
    }
    catch { }
    Write-Log $Text
}

# Writes the file to disk for real (not just the cache), then swaps it in,
# so a crash can never leave a half-written file behind
function Write-JsonFile([string] $Path, $Object) {
    $json  = $Object | ConvertTo-Json -Depth 12
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $tmp   = "$Path.tmp"

    $fs = [IO.File]::Open($tmp, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $fs.Write($bytes, 0, $bytes.Length)
        $fs.Flush($true)
    }
    finally {
        $fs.Close()
    }

    for ($try = 1; $try -le 5; $try++) {
        try {
            if (Test-Path -LiteralPath $Path) { [IO.File]::Replace($tmp, $Path, "$Path.bak") }
            else { [IO.File]::Move($tmp, $Path) }
            return
        }
        catch {
            if ($try -eq 5) { throw }
            Start-Sleep -Milliseconds 200   # a reader may have the file open for a moment
        }
    }
}

function Read-JsonFile([string] $Path) {
    foreach ($file in @($Path, "$Path.bak")) {
        for ($try = 1; $try -le 3; $try++) {
            try {
                if (-not (Test-Path -LiteralPath $file)) { break }
                $fs = [IO.File]::Open($file, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
                try {
                    $reader = New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8)
                    $raw = $reader.ReadToEnd()
                }
                finally {
                    $fs.Close()
                }
                if ($raw.Trim().Length -gt 0) { return ($raw | ConvertFrom-Json) }
                break
            }
            catch {
                Start-Sleep -Milliseconds 150
            }
        }
    }
    return $null
}

# Last lines of a text file that another process may still be writing
function Get-FileTail([string] $Path, [int] $Lines = 20) {
    try {
        $fs = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
        try {
            $len = $fs.Length
            $start = [Math]::Max(0, $len - 16384)
            [void]$fs.Seek($start, [IO.SeekOrigin]::Begin)
            $reader = New-Object IO.StreamReader($fs, [Text.Encoding]::UTF8)
            $text = $reader.ReadToEnd()
        }
        finally {
            $fs.Close()
        }
        $all = $text -split "`r?`n" | Where-Object { $_.Trim().Length -gt 0 }
        return @($all | Select-Object -Last $Lines)
    }
    catch {
        return @()
    }
}
