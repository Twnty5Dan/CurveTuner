# CurveTuner - WHEA errors and crash records from the Windows event log

# APIC ID -> core, from the table CoreCycler's APICID.exe gave at setup (lib\Cpu.ps1).
# The IDs have gaps (a 5900X uses 0-11 and 16-27), so they are looked up, not calculated.
# $null when the ID is not in the table: then no core is blamed.
function Get-CoreFromApic([int] $Apic) {
    if ($script:ApicToCore.ContainsKey($Apic)) { return [int]$script:ApicToCore[$Apic] }
    return $null
}

# WHEA 18 = fatal (logged after the reboot), WHEA 19 = corrected error
function Get-WheaErrors([datetime] $Since) {
    $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-WHEA-Logger'; Id = 18, 19; StartTime = $Since } -ErrorAction SilentlyContinue)

    foreach ($e in $events) {
        $apic = $null
        try {
            $xml  = [xml]$e.ToXml()
            $node = $xml.Event.EventData.Data | Where-Object { $_.Name -eq 'ApicId' } | Select-Object -First 1
            if ($node) { $apic = [int]$node.'#text' }
        }
        catch { }

        if ($null -eq $apic -and $e.Message -match 'APIC ID:\s*(\d+)') { $apic = [int]$Matches[1] }

        $core = $null
        if ($null -ne $apic) { $core = Get-CoreFromApic $apic }

        [pscustomobject]@{ Time = $e.TimeCreated; Id = $e.Id; Apic = $apic; Core = $core }
    }
}

# Kernel-Power 41 = rebooted without a clean shutdown (crash, freeze + reset button),
# EventLog 6008 = unexpected shutdown
function Get-CrashEvents([datetime] $Since) {
    @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Microsoft-Windows-Kernel-Power'; Id = 41; StartTime = $Since } -ErrorAction SilentlyContinue)
    @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'EventLog'; Id = 6008; StartTime = $Since } -ErrorAction SilentlyContinue)
}
