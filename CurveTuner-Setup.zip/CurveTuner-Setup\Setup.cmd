@echo off
rem CurveTuner setup: double-click this file. Windows asks for admin rights (click Yes).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup.ps1"
