CurveTuner - automatic per-core Curve Optimizer for AMD Ryzen
==============================================================

What it does
  Finds, core by core, how far each CPU core can be undervolted with Curve Optimizer and stay 100%
  stable. Result: lower temperatures and higher boost clocks at the same power. It tests every value
  itself (Prime95 and y-cruncher through CoreCycler, WHEA error checks, a clock check), continues by
  itself after a crash, and at the end shows the values you type into the BIOS once.

  Works with: AMD Ryzen 5000, 7000, 8000G and 9000 desktop CPUs, Windows 10 or 11.
  Not with: laptops, Ryzen 5800X3D / 5700X3D (Curve Optimizer locked), Ryzen 3000 and older.

1. Install (once, needs internet)
  - Copy this whole folder to the PC (a USB stick is easiest).
  - Double-click Setup.cmd and click "Yes" when Windows asks for admin rights.
  - Setup checks the CPU and installs what CurveTuner needs: .NET 8 Runtime, Visual C++ runtimes,
    the PawnIO driver (lets CurveTuner set Curve Optimizer from Windows), and CoreCycler with Prime95
    and y-cruncher - all from their official sources, the CoreCycler download is checked. CurveTuner
    goes to C:\CurveTuner, with a "CurveTuner" icon on the desktop.

2. BIOS, once before the first start
  Restart, open the BIOS (usually Del, sometimes F2) and find the AMD Overclocking menu:
    ASUS:     F7 (Advanced Mode) > Advanced > AMD Overclocking > Precision Boost Overdrive
    MSI:      F7 (Advanced) > OC > Advanced CPU Configuration > AMD Overclocking > Precision Boost Overdrive
    Gigabyte: F2 (Advanced Mode) > Tweaker > Advanced CPU Settings > Precision Boost Overdrive
    ASRock:   Advanced > AMD Overclocking > Precision Boost Overdrive
  Set:  Precision Boost Overdrive = Advanced   (NOT "Enabled": on many boards that also lifts the power
                                                limits, too hot with a stock cooler)
        PBO Limits = Auto   (stock power)
        Curve Optimizer = Per Core   (every core: Negative, magnitude 0)
  Save with F10. CurveTuner checks in its self-test that this works.
  Recommended: if the board waits for a key press after a crash (ASUS: Boot > "Wait For F1 If Error"),
  switch that off, so a crash during testing restarts straight into Windows.

3. Run CurveTuner (overnight: roughly 1 hour per core, e.g. 8 cores = about 10 hours)
  - Double-click "CurveTuner" on the desktop, click "Yes", answer the questions with Y.
  - It runs in the background from Windows startup, also at the PIN / login screen. A crash or a
    restart during testing is normal: that value was too low, CurveTuner notes it and continues.
  - If the PC freezes instead of restarting (Ryzen 9000 does that), press the reset button.
  - Press P in the CurveTuner window to pause when you want to use the PC, R to continue.

4. At the end: the final values into the BIOS
  CurveTuner shows a table (also in C:\CurveTuner\BIOS-values.txt): per core a sign (Negative /
  Positive) and a magnitude. Enter them in the BIOS under Curve Optimizer > Per Core, save with F10.
  After the restart CurveTuner checks by itself that every value is right, and keeps watching for
  errors in daily use (it tells you if a core needs one step less).

Undo everything
  BIOS: Curve Optimizer back to all 0 (or Precision Boost Overdrive back to Auto).
  Remove the background tasks: CurveTuner.exe -Uninstall (or delete the tasks "CurveTuner Engine" and
  "CurveTuner View" in Task Scheduler). PawnIO, .NET and Visual C++ can be removed under Settings > Apps.

Files
  C:\CurveTuner\BIOS-values.txt     the final values
  C:\CurveTuner\data\history.log    everything CurveTuner did, in plain words
