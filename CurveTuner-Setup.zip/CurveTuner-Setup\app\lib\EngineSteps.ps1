﻿# CurveTuner - the engine's work steps. Each call does one unit of work and returns,
# so pause commands are picked up between them (and during them through $script:OnTick).

# 1. Proves everything works before any tuning: setting values from Windows, CoreCycler in the background
function Invoke-SelfTest {
    $s    = $script:State
    $core = $Config.NumCores - 1
    $bios = [int]$s.bios[$core]
    $up   = [int][Math]::Min($bios + 1, $Config.MaxValue)   # one step LESS negative = safe
    Write-History 'Self-test started'

    Set-Current 'selftest' $core $up 'selftest' 'self-test: setting a value from Windows'
    Update-Status 'self-test: setting a value from Windows'
    Set-CoOffsets @{ $core = $up }
    Set-CoOffsets @{ $core = $bios }
    Write-History ("Self-test: core {0} set to {1} and back to {2}, both read back correctly" -f $core, (Format-Short $up), (Format-Short $bios))

    $s.current.stageName = 'self-test: 1-minute Prime95 run in the background'
    Save-State
    $r = Invoke-CoreCycler @($core) $Profiles.selftest[0] $script:OnTick

    if ($r.Status -eq 'abort') { Resolve-Interrupted 'paused'; return }
    if ($r.Status -in 'setup-error', 'inconclusive') {
        $s.phase     = 'error'
        $s.errorKind = 'setup'
        Add-Alert ("Self-test failed: CoreCycler could not run in the background ({0}). Nothing was tuned. It runs again after the next restart." -f $r.Detail) 'error'
        Clear-Current
        return
    }
    if ($r.Status -eq 'fail') {
        Add-CoreHistory $s.cores[$core] 'baseline' $bios 'FAIL' ('self-test: ' + $r.Detail)
        Add-Alert ("Core {0} failed the self-test at its normal value {1}. It gets a safer value at every boot." -f $core, (Format-Short $bios)) 'warning'
    }

    Set-Current 'selftest' -1 $null 'selftest' 'self-test: all-core benchmark'
    Update-Status 'self-test: all-core benchmark'
    $benchStart = Get-Date
    $all = Measure-AllCorePerf
    $benchCores = @(Get-WheaErrors -Since $benchStart | Where-Object { $null -ne $_.Core } | ForEach-Object { [int]$_.Core } | Sort-Object -Unique)
    Set-OtherCoreErrors $benchCores -1 'WHEA error during the self-test all-core benchmark'
    $s.allCore = [pscustomobject]@{ biosMHz = $all.effMHz; biosScore = $all.score; finalMHz = $null; finalScore = $null }
    Write-History ("Self-test: all-core benchmark at your BIOS values: {0} MHz, score {1}" -f $all.effMHz, $all.score)

    # Does a value set from Windows really change anything? Without PBO in the BIOS it may not, and then every
    # test would "pass" down to the minimum - values that would crash once entered in the BIOS.
    $s.current.stageName = 'self-test: does Curve Optimizer from Windows have an effect?'
    Save-State
    $effect = Test-CoEffect
    if ($null -eq $effect) { Resolve-Interrupted (Get-InterruptReason); Set-SafeValues; return }
    if (-not $effect.Ok) {
        $hint = Get-BiosHint $script:CpuProfile.boardVendor
        $s.phase     = 'error'
        $s.errorKind = 'co-effect'
        Add-Alert ("Curve Optimizer values set from Windows have no effect on this PC ({0}). Most likely Precision Boost Overdrive is off: in the BIOS ({1}: {2}) set Precision Boost Overdrive to Advanced (PBO Limits Auto) and Curve Optimizer to Per Core, save and restart. The self-test then runs again by itself." -f $effect.Text, $hint.Key, $hint.Path) 'error'
        Clear-Current
        Set-SafeValues
        return
    }

    $s.current = $null
    $s.phase   = 'search'
    Add-Alert ("Self-test passed: values can be set from Windows and they work ({0}), CoreCycler runs in the background. Tuning starts." -f $effect.Text) 'success'
    Save-State
}

# All-core clock at the normal values against all cores $Config.EffectStep steps LESS negative (more voltage, which
# is safe). The order normal / safer / normal cancels out the CPU warming up. Two tries.
# Returns @{ Ok; Drop; Text } or $null when interrupted.
function Test-CoEffect {
    $base = Get-SafeValues
    $plus = @($base | ForEach-Object { [int][Math]::Min([int]$_ + $Config.EffectStep, $Config.MaxValue) })
    $last = $null
    for ($round = 1; $round -le 2; $round++) {
        $runs = @()
        foreach ($vals in @(, $base) + @(, $plus) + @(, $base)) {
            Set-AllCoOffsets $vals
            if (-not (Wait-Ticking 8 'self-test: Curve Optimizer effect check')) { Set-AllCoOffsets $base; return $null }
            Update-Status 'self-test: Curve Optimizer effect check'
            $runs += Measure-AllCorePerf
        }
        $last = Get-CoEffectVerdict $runs[0] $runs[1] $runs[2]
        Write-History ('Self-test: ' + $last.Text)
        if ($last.Ok) { return $last }
    }
    return $last
}

# Clock drop between the normal runs (average) and the safer run; the score when the clock counter is missing
function Get-CoEffectVerdict($Before, $Safer, $After) {
    $useClock = $Before.effMHz -gt 0 -and $After.effMHz -gt 0 -and $Safer.effMHz -gt 0
    if ($useClock) { $ref = ($Before.effMHz + $After.effMHz) / 2.0; $val = [double]$Safer.effMHz; $unit = 'MHz' }
    else { $ref = ($Before.score + $After.score) / 2.0; $val = [double]$Safer.score; $unit = 'points' }
    $drop = 0.0
    if ($ref -gt 0) { $drop = 100 * (1 - $val / $ref) }
    $text = 'all-core {0:N0} {1} at the normal values, {2:N0} {1} with all cores {3} steps safer ({4:N1}% lower)' -f $ref, $unit, $val, $Config.EffectStep, $drop
    return @{ Ok = ($drop -ge $Config.EffectMinPct); Drop = [Math]::Round($drop, 2); Text = $text }
}

function Test-Stretch($Perf, $Ref) {
    if (-not $Perf -or -not $Ref -or -not $Perf.effMHz -or -not $Ref.effMHz -or -not $Ref.score) { return $null }
    $mhzDrop   = 100 * (1 - $Perf.effMHz / [double]$Ref.effMHz)
    $scoreDrop = 100 * (1 - $Perf.score / [double]$Ref.score)
    if ($mhzDrop -gt $Config.StretchPct -and $scoreDrop -gt $Config.StretchPct) {
        return ('clock stretching: {0} MHz vs {1} MHz at the normal value (-{2:N1}%)' -f $Perf.effMHz, $Ref.effMHz, $mhzDrop)
    }
    return $null
}

# Waits while keeping the heartbeat and pause button alive. Returns $false when aborted.
function Wait-Ticking([int] $Seconds, [string] $Activity) {
    for ($i = 0; $i -lt $Seconds; $i++) {
        if ((& $script:OnTick $i $Seconds $null) -eq 'abort') { return $false }
        Update-Status $Activity $i $Seconds
        Start-Sleep -Seconds 1
    }
    return $true
}

# A/B clock check: the same core at the test value and at its normal value, right after each other,
# so temperature and background load are the same for both. Returns $null when aborted.
function Invoke-ABCheck($C, [int] $Core, [int] $Value, [int] $RefValue) {
    $s = $script:State
    $s.current.kind      = 'ab'
    $s.current.stageName = 'clock check'
    Save-State

    if (-not (Wait-Ticking $Config.BenchCooldownSec 'clock check: cooling down')) { return $null }
    Update-Status 'clock check: test value'
    $perf = Measure-CorePerf $Core
    Set-CoOffsets @{ $Core = $RefValue }
    Start-Sleep -Seconds 3
    Update-Status 'clock check: normal value'
    $ref = Measure-CorePerf $Core
    $stretch = Test-Stretch $perf $ref

    if ($stretch) {
        # Slower: measure both once more before deciding, and keep the best of each
        Set-CoOffsets @{ $Core = $Value }
        Start-Sleep -Seconds 3
        $perf2 = Measure-CorePerf $Core
        Set-CoOffsets @{ $Core = $RefValue }
        Start-Sleep -Seconds 3
        $ref2 = Measure-CorePerf $Core
        $perf = [pscustomobject]@{ effMHz = [Math]::Max($perf.effMHz, $perf2.effMHz); score = [Math]::Max($perf.score, $perf2.score) }
        $ref  = [pscustomobject]@{ effMHz = [Math]::Max($ref.effMHz, $ref2.effMHz);  score = [Math]::Max($ref.score, $ref2.score) }
        $stretch = Test-Stretch $perf $ref
    }
    return @{ Perf = $perf; Ref = $ref; Stretch = $stretch }
}

function Get-InterruptReason {
    $reason = 'stopped'
    if ($script:GapReason) { $reason = $script:GapReason }
    elseif ($script:State.paused) { $reason = 'paused' }
    $script:GapReason = ''
    return $reason
}

# Errors on cores that were NOT being tested: they were at their normal value, so that value is the problem
function Set-OtherCoreErrors([int[]] $ErrorCores, [int] $TestedCore, [string] $Detail) {
    foreach ($o in ($ErrorCores | Where-Object { $_ -ne $TestedCore })) {
        $oc = $script:State.cores[$o]
        $v  = Get-SafeValue $oc ([int]$script:State.bios[$o])
        Add-CoreHistory $oc 'baseline' $v 'FAIL' ("error at its normal value while core {0} was tested: {1}" -f $TestedCore, $Detail)
        Add-Alert ("Core {0} had an error at its normal value {1}. It gets {2} at every boot from now on." -f $o, (Format-Short $v), (Format-Short (Get-SafeValue $oc ([int]$script:State.bios[$o])))) 'warning'
    }
}

# 2. One test of the per-core search
function Invoke-SearchStep {
    $s = $script:State
    $c = $s.cores | Where-Object { $_.status -ne 'done' } | Select-Object -First 1
    if (-not $c) {
        $s.phase         = 'combined'
        $s.combinedStage = 0
        Add-Alert ('All {0} limits found. Next: the final validation with all cores at their final values.' -f $Config.NumCores) 'success'
        Save-State
        return
    }

    $i    = [int]$c.core
    $bios = [int]$s.bios[$i]
    $t    = Get-NextTest $c $bios
    if (-not $t) { Save-State; return }
    if (-not $c.startedAt) { $c.startedAt = Get-NowIso }

    $stages = $Profiles[$t.Profile]
    $label  = 'quick test'
    if ($t.Profile -eq 'confirm') { $label = 'long confirmation test' }
    Write-History ("Core {0}: {1} at {2}" -f $i, $label, (Format-Short $t.Value))

    # Only this core gets the test value, all other cores stay at their safe values
    Set-SafeValues
    Set-Current 'core' $i $t.Value $t.Profile $stages[0].Name
    Set-CoOffsets @{ $i = $t.Value }

    foreach ($stage in $stages) {
        $s.current.stageName = $stage.Name
        Save-State
        $r = Invoke-CoreCycler @($i) $stage $script:OnTick

        # The value must still be applied (sleep or hibernation would have reset it)
        $still = Get-CoOffsets
        if ($r.Status -eq 'abort' -or $still[$i] -ne $t.Value) {
            Resolve-Interrupted (Get-InterruptReason)
            Set-SafeValues
            return
        }
        if ($r.Status -eq 'setup-error') {
            Resolve-Interrupted 'CoreCycler problem'
            Set-Paused ('CoreCycler problem: ' + $r.Detail)
            Add-Alert ('Paused because of a CoreCycler problem: ' + $r.Detail) 'error'
            Set-SafeValues
            Save-State
            return
        }
        Set-OtherCoreErrors $r.ErrorCores $i $r.Detail
        if ($r.Status -eq 'fail' -and $r.ErrorCores -contains $i) {
            $detail = '{0}: {1}' -f $stage.Name, $r.Detail
            Complete-Test $c $t.Value $t.Profile 'FAIL' $detail
            Write-History ("Core {0}: {1} FAILED - {2}" -f $i, (Format-Short $t.Value), $detail)
            Clear-Current
            Set-SafeValues
            return
        }
        if ($r.Status -eq 'inconclusive') {
            Resolve-Interrupted $r.Detail
            Set-SafeValues
            return
        }
    }

    if ($t.Profile -eq 'quick') {
        $abStart = Get-Date
        $ab = Invoke-ABCheck $c $i $t.Value (Get-SafeValue $c $bios)
        if ($null -eq $ab) {
            Resolve-Interrupted (Get-InterruptReason)
            Set-SafeValues
            return
        }

        # WHEA errors during the clock check count as well
        $abCores = @(Get-WheaErrors -Since $abStart | Where-Object { $null -ne $_.Core } | ForEach-Object { [int]$_.Core } | Sort-Object -Unique)
        Set-OtherCoreErrors $abCores $i 'WHEA error during the clock check'
        if ($abCores -contains $i) {
            Complete-Test $c $t.Value 'quick' 'FAIL' 'WHEA error during the clock check'
            Write-History ("Core {0}: {1} FAILED - WHEA error during the clock check" -f $i, (Format-Short $t.Value))
            Clear-Current
            Set-SafeValues
            return
        }

        if ($ab.Stretch) {
            Complete-Test $c $t.Value 'quick' 'STRETCH' $ab.Stretch $ab.Perf $ab.Ref
            Write-History ("Core {0}: {1} is stable but slower - {2}" -f $i, (Format-Short $t.Value), $ab.Stretch)
        }
        else {
            Complete-Test $c $t.Value 'quick' 'PASS' '' $ab.Perf $ab.Ref
            Write-History ("Core {0}: {1} passed ({2} MHz, normal value {3} MHz)" -f $i, (Format-Short $t.Value), $ab.Perf.effMHz, $ab.Ref.effMHz)
        }
    }
    else {
        Complete-Test $c $t.Value 'confirm' 'PASS'
        Write-History ("Core {0}: limit {1} confirmed, final value {2}" -f $i, (Format-Short $t.Value), (Format-Short $c.final))
    }

    Clear-Current
    Set-SafeValues
    Save-State
}

# 3. Final validation with all cores at their final values at the same time:
#    stage 0/1 = CoreCycler through every core, 2 = idle/boost-spike test, 3 = all-core benchmark
function Invoke-CombinedStep {
    $s = $script:State
    if ($s.combinedRuns -ge $Config.MaxCombinedRuns) {
        Set-Paused 'the final validation failed too often'
        Add-Alert 'Paused: the final validation failed too often. Ask for help with history.log.' 'error'
        Save-State
        return
    }

    $finals = @($s.cores | ForEach-Object { [int]$_.final })
    $all    = @(0..($Config.NumCores - 1))
    $stageNo = [int]$s.combinedStage

    if ($stageNo -le 1) {
        $stage = $Profiles.combined[$stageNo]
        Set-AllCoOffsets $finals
        Set-Current 'combined' -1 $null 'combined' $stage.Name
        Write-History ("Final validation: {0}" -f $stage.Name)
        $r = Invoke-CoreCycler $all $stage $script:OnTick

        $still = Get-CoOffsets
        $applied = @(0..($Config.NumCores - 1) | Where-Object { $still[$_] -ne $finals[$_] }).Count -eq 0
        if ($r.Status -eq 'abort' -or -not $applied) { Resolve-Interrupted (Get-InterruptReason); Set-SafeValues; return }
        if ($r.Status -eq 'setup-error') {
            Resolve-Interrupted 'CoreCycler problem'
            Set-Paused ('CoreCycler problem: ' + $r.Detail)
            Add-Alert ('Paused because of a CoreCycler problem: ' + $r.Detail) 'error'
            Set-SafeValues
            Save-State
            return
        }
        if ($r.Status -eq 'inconclusive') { Resolve-Interrupted $r.Detail; Set-SafeValues; return }

        if ($r.Status -eq 'fail') {
            foreach ($e in $r.ErrorCores) {
                Set-CombinedFail $s.cores[$e] ('{0}: {1}' -f $stage.Name, $r.Detail)
                Write-History ("Core {0}: final value failed in {1}, now {2}" -f $e, $stage.Name, (Format-Short $s.cores[$e].final))
            }
            $s.combinedStage = 0
            $s.combinedRuns++
        }
        else {
            $s.combinedStage = $stageNo + 1
        }
        Clear-Current
        Set-SafeValues
        return
    }

    if ($stageNo -eq 2) {
        Set-AllCoOffsets $finals
        Write-History 'Final validation: idle/boost-spike test on every core'
        foreach ($core in $all) {
            Set-Current 'burst' $core ([int]$finals[$core]) 'combined' 'idle/boost-spike test'
            $seconds = 60 * $Config.BurstMinutesPerCore
            for ($chunk = 0; $chunk -lt $seconds / 10; $chunk++) {
                if ((& $script:OnTick ($chunk * 10) $seconds $core) -eq 'abort') { Resolve-Interrupted (Get-InterruptReason); Set-SafeValues; return }
                $from   = Get-Date
                $threads = Get-CoreCpus $core
                $cpu    = $threads[$chunk % $threads.Count]   # alternate between the threads of the core
                $errors = Invoke-Burst $cpu 10000
                $whea   = @(Get-WheaErrors -Since $from | Where-Object { $null -ne $_.Core })
                $bad    = @($whea | ForEach-Object { [int]$_.Core })
                if ($errors -ne 0) { $bad += $core }
                if ($bad.Count -gt 0) {
                    foreach ($b in ($bad | Sort-Object -Unique)) {
                        Set-CombinedFail $s.cores[$b] 'idle/boost-spike test: calculation or WHEA error'
                        Write-History ("Core {0}: final value failed the idle/boost-spike test, now {1}" -f $b, (Format-Short $s.cores[$b].final))
                    }
                    $s.combinedStage = 0
                    $s.combinedRuns++
                    Clear-Current
                    Set-SafeValues
                    return
                }
            }
        }
        $s.combinedStage = 3
        Clear-Current
        return
    }

    # Stage 3: how much faster the whole CPU is now
    Set-Current 'allcore' -1 $null 'combined' 'all-core benchmark: before and after'
    Set-SafeValues
    if (-not (Wait-Ticking 10 'all-core benchmark: cooling down')) { Resolve-Interrupted (Get-InterruptReason); return }
    $before = Measure-AllCorePerf
    Set-AllCoOffsets $finals
    if (-not (Wait-Ticking 10 'all-core benchmark: cooling down')) { Resolve-Interrupted (Get-InterruptReason); Set-SafeValues; return }
    $finalStart = Get-Date
    $after = Measure-AllCorePerf

    # A WHEA error under all-core load at the final values: back that core off and validate again
    $benchCores = @(Get-WheaErrors -Since $finalStart | Where-Object { $null -ne $_.Core } | ForEach-Object { [int]$_.Core } | Sort-Object -Unique)
    if ($benchCores.Count -gt 0) {
        foreach ($b in $benchCores) {
            Set-CombinedFail $s.cores[$b] 'WHEA error under all-core load'
            Write-History ("Core {0}: final value failed under all-core load, now {1}" -f $b, (Format-Short $s.cores[$b].final))
        }
        $s.combinedStage = 0
        $s.combinedRuns++
        Clear-Current
        Set-SafeValues
        return
    }
    $s.allCore = [pscustomobject]@{ biosMHz = $before.effMHz; biosScore = $before.score; finalMHz = $after.effMHz; finalScore = $after.score }
    $gain = 100 * ($after.score / [double]$before.score - 1)

    $s.phase   = 'bios'
    $s.current = $null
    Set-SafeValues
    Write-BiosFile
    Write-History ("All-core: {0} MHz -> {1} MHz, score {2:+0.0;-0.0;0.0}%" -f $before.effMHz, $after.effMHz, $gain)
    Add-Alert ("Tuning finished! Enter the final values in the BIOS (see BIOS-values.txt). All-core gain: {0:+0.0;-0.0;0.0}%." -f $gain) 'success'
    Save-State
}

# At boot in the 'bios' phase: did the user enter the final values correctly?
function Test-BiosEntry {
    $s = $script:State
    $wrong = @()
    $untouched = $true
    for ($i = 0; $i -lt $Config.NumCores; $i++) {
        if ([int]$s.bios[$i] -ne [int]$s.cores[$i].final) {
            $wrong += ("Core {0} is {1}, should be {2}" -f $i, (Format-Short $s.bios[$i]), (Format-Short $s.cores[$i].final))
        }
        if ([int]$s.bios[$i] -ne [int]$s.biosAtStart[$i]) { $untouched = $false }
    }

    if ($wrong.Count -eq 0) {
        $s.phase          = 'done'
        $s.lastEventCheck = Get-NowIso
        Write-BiosFile
        Add-Alert 'Checked: your BIOS has exactly the final values. Tuning complete!' 'success'
    }
    elseif (-not $untouched) {
        Add-Alert ('Some BIOS values are not right: ' + ($wrong -join '; ')) 'warning'
    }
}

# At boot in the 'done' phase: WHEA errors in daily use get a small step back
function Invoke-Watch {
    $s     = $script:State
    $since = ConvertFrom-Iso $s.lastEventCheck
    $whea  = @(Get-WheaErrors -Since $since | Where-Object { $null -ne $_.Core })
    $crash = @(Get-CrashEvents -Since $since)
    $s.lastEventCheck = Get-NowIso

    foreach ($core in @($whea | ForEach-Object { [int]$_.Core } | Sort-Object -Unique)) {
        $c    = $s.cores[$core]
        $bios = [int]$s.bios[$core]
        $w    = $whea | Where-Object { $_.Core -eq $core } | Select-Object -First 1
        Add-CoreHistory $c 'daily' $bios 'FAIL' ("WHEA error in daily use at {0}" -f $w.Time)
        $c.final = Get-SafeValue $c $bios
        Add-Alert ("Core {0} had a WHEA error during normal use ({1}). It gets {2} from now on at every boot; please also change it in the BIOS from {3} to {2}." -f $core, $w.Time, (Format-Short $c.final), (Format-Short $bios)) 'warning'
    }
    if ($whea.Count -eq 0 -and $crash.Count -gt 0) {
        Add-Alert 'Windows restarted unexpectedly since the last check, but no core was named. If it happens again, tell me.' 'info'
    }
    if ($whea.Count -gt 0) { Write-BiosFile }
    Save-State
    return ($whea.Count -gt 0)
}

function Get-BiosLines {
    $s = $script:State
    $hint = Get-BiosHint $script:CpuProfile.boardVendor
    $lines = @(
        ('BIOS:  ' + $hint.Key),
        ('       ' + $hint.Path)
    )
    if ($hint.Alt) { $lines += ('       (' + $hint.Alt + ')') }
    $lines += @(
        '       Precision Boost Overdrive = Advanced,  PBO Limits = Auto,  Curve Optimizer = Per Core',
        '',
        '   Core    Sign        Magnitude      (now)',
        '   ----    --------    ---------      -----'
    )
    for ($i = 0; $i -lt $Config.NumCores; $i++) {
        $v    = [int]$s.cores[$i].final
        $mark = ''
        if ($v -ne [int]$s.bios[$i]) { $mark = '   <- change' }
        $lines += ('   {0,4}    {1,-8}    {2,9}      {3,5}{4}' -f $i, (Get-BiosSign $v), [Math]::Abs($v), (Format-Short $s.bios[$i]), $mark)
    }
    $lines += ''
    $lines += 'Leave everything else as it is. Save with F10.'
    $lines += 'After the restart CurveTuner checks by itself that the values are right.'
    return $lines
}

function Write-BiosFile {
    $content = @('CurveTuner - final Curve Optimizer values', ('Written ' + (Get-Date -Format 'yyyy-MM-dd HH:mm')), '') + (Get-BiosLines)
    try { Set-Content -LiteralPath $BiosFile -Value $content -Encoding UTF8 } catch { Write-Log ('Could not write BIOS-values.txt: ' + $_.Exception.Message) }
}
