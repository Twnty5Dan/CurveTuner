﻿# CurveTuner - setup, reset and uninstall (admin)

function Read-Choice([string] $Prompt, [string[]] $Keys) {
    while ($true) {
        Write-Host $Prompt -ForegroundColor Cyan -NoNewline
        $key = [Console]::ReadKey($true).KeyChar.ToString().ToUpperInvariant()
        Write-Host " $key"
        if ($Keys -contains $key) { return $key }
    }
}

function Show-SetupHeader {
    Clear-Host
    Say '  ================================================================' DarkCyan
    Say '   CurveTuner setup  -  automatic per-core Curve Optimizer' Cyan
    Say '  ================================================================' DarkCyan
    Say ''
}

# The engine runs as SYSTEM, so nobody but admins may change its files.
# Only the top folder gets explicit rules; everything inside inherits them.
function Protect-Folder {
    New-Item -ItemType Directory -Force $DataDir, $ControlDir | Out-Null

    & icacls.exe $Root /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' /Q | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Could not protect $Root (icacls exit code $LASTEXITCODE)" }

    & icacls.exe (Join-Path $Root '*') /reset /T /C /Q | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Could not reset the permissions inside $Root (icacls exit code $LASTEXITCODE)" }

    # The dashboard sends pause / resume through this folder without admin rights
    & icacls.exe $ControlDir /grant '*S-1-5-32-545:(OI)(CI)M' /Q | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Could not open $ControlDir for the dashboard (icacls exit code $LASTEXITCODE)" }

    # Check the result on files that matter: every one must have permission entries again
    foreach ($f in @($ScriptPath, (Join-Path $Root 'lib\Engine.ps1'), (Join-Path $Root 'CurveTuner.exe'), $StateFile)) {
        if ((Test-Path -LiteralPath $f) -and @((Get-Acl -LiteralPath $f).Access).Count -lt 3) {
            throw "The permissions of $f are not right after protecting the folder"
        }
    }
}

function Register-Tasks {
    Unregister-ScheduledTask -TaskName $Config.LegacyTask -Confirm:$false -ErrorAction SilentlyContinue

    $engineArgs = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Engine' -f $ScriptPath
    $action     = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $engineArgs -WorkingDirectory $Root
    $trigger    = New-ScheduledTaskTrigger -AtStartup
    $principal  = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $settings   = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
                    -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -Priority 4 `
                    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
    Register-ScheduledTask -TaskName $Config.EngineTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null

    $user       = "$env:USERDOMAIN\$env:USERNAME"
    $viewArgs   = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -ViewAtLogon' -f $ScriptPath
    $action     = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $viewArgs -WorkingDirectory $Root
    $trigger    = New-ScheduledTaskTrigger -AtLogOn -User $user
    $principal  = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
    $settings   = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)
    Register-ScheduledTask -TaskName $Config.ViewTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
}

function Stop-Engine {
    if (Test-Path -LiteralPath $ControlDir) { Set-Content -LiteralPath $CommandFile -Value 'pause' -Encoding ASCII -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 5
    Stop-ScheduledTask -TaskName $Config.EngineTask -ErrorAction SilentlyContinue
    Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*CurveTuner.ps1*-Engine*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Stop-TestPrograms
}

# Puts every core back to its BIOS value (they would be back after a restart anyway)
function Restore-BiosValues {
    $S = Read-JsonFile $StateFile
    if ($S -and $S.bios) {
        if ($S.cpu) { Initialize-CpuConfig $S.cpu } else { $Config.NumCores = @($S.bios).Count }
        try { Set-AllCoOffsets @($S.bios); Say '  All cores are back at their BIOS values.' Green }
        catch { Say '  Could not reset the values now. A restart brings back the BIOS values anyway.' Yellow }
    }
}

function Invoke-Setup {
    Show-SetupHeader

    $script:CcDir = Find-CoreCycler
    $problems = @(Test-Prerequisites)
    if ($problems.Count -gt 0) {
        Say '  Something CurveTuner needs is missing (run Setup.cmd again):' Red
        foreach ($p in $problems) { Say "   - $p" Red }
        Read-Host '  Press Enter to close' | Out-Null
        return
    }

    Say '  Looking at the CPU...' DarkGray
    $cpu = Get-CpuProfile
    if ($cpu.problem) {
        Say ('  ' + $cpu.problem) Red
        Read-Host '  Press Enter to close' | Out-Null
        return
    }
    Initialize-CpuConfig $cpu
    $hint = Get-BiosHint $cpu.boardVendor
    Say ('  CPU:    {0}  ({1}, {2} cores, {3} threads)' -f (Get-CpuShortName), $cpu.generation, $cpu.numCores, $cpu.logicalCount) White
    Say ('  Board:  {0} {1}' -f $cpu.boardVendor, $cpu.boardName) White
    Say ('  Curve Optimizer goes down to {0} on this CPU; CurveTuner searches each core''s limit in that range.' -f $cpu.minValue) DarkGray
    Say ''

    # Ignore this window and the one that launched it (it may still be closing)
    $launcher = (Get-CimInstance Win32_Process -Filter "ProcessId = $PID").ParentProcessId
    $otherRunning = @(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessId -ne $PID -and $_.ProcessId -ne $launcher -and $_.CommandLine -like '*CurveTuner.ps1*' -and $_.CommandLine -notlike '*-Engine*' -and $_.CommandLine -notlike '*-View*' })
    if ($otherRunning.Count -gt 0) {
        Say '  Another CurveTuner window is still open. Close it, then start CurveTuner again.' Yellow
        Read-Host '  Press Enter to close' | Out-Null
        return
    }

    Say '  Reading the current Curve Optimizer values...' DarkGray
    $bios = Get-CoOffsets
    for ($from = 0; $from -lt $Config.NumCores; $from += 8) {
        $to = [Math]::Min($Config.NumCores, $from + 8) - 1
        Say ('  Core:   ' + (($from..$to | ForEach-Object { '{0,4}' -f $_ }) -join ''))
        Say ('  Value:  ' + (($from..$to | ForEach-Object { '{0,4}' -f (Format-Short $bios[$_]) }) -join '')) White
    }
    Say ''
    Say '  Curve Optimizer only works with Precision Boost Overdrive switched on in the BIOS:' White
    Say ('   {0}:  {1}' -f $hint.Key, $hint.Path)
    if ($hint.Alt) { Say ('   ({0})' -f $hint.Alt) DarkGray }
    Say '   Precision Boost Overdrive = Advanced,  PBO Limits = Auto (stock power),  Curve Optimizer = Per Core'
    Say '   (every core at 0 if you never changed it). CurveTuner also checks this itself in its self-test.' DarkGray
    Say ''
    if ((Read-Choice '  Is that set, and are the values above the ones in your BIOS?  [Y] yes   [N] no   ' @('Y', 'N')) -eq 'N') {
        Say '  Set it in the BIOS as shown above, save, restart, then start CurveTuner again.' Yellow
        Read-Host '  Press Enter to close' | Out-Null
        return
    }

    $hours = [Math]::Ceiling($Config.NumCores * $(if ($Config.MinValue -le -50) { 1.3 } else { 1.0 }) + 2)
    Say ''
    Say '  How it works:' White
    Say '   - It runs in the background from Windows startup. After a crash it continues by itself,'
    Say '     even while the PC waits at the PIN screen. You do not need to log in.'
    Say '   - Only one core at a time gets a test value; values set from Windows are temporary,'
    Say '     so every restart brings back your BIOS values.'
    Say ("   - It takes about {0}-{1} hours in total (best: run it overnight, leave the PC alone)." -f ($hours - 2), ($hours + 2))
    Say '     Press P in the CurveTuner window to pause when you want to use the PC.'
    Say '   - If the PC ever freezes instead of restarting, press the reset button (Ryzen 9000 does that often).'
    Say '   - If the PC stops at a BIOS screen after a crash ("press F1" or similar), switch that wait off in'
    Say '     the BIOS (on ASUS: Boot > "Wait For F1 If Error" = Disabled).'
    Say '   - At the end you enter the final values in the BIOS once; CurveTuner checks them.'
    Say ''
    if ((Read-Choice '  Start?  [Y] yes   [N] no   ' @('Y', 'N')) -eq 'N') { return }

    New-Item -ItemType Directory -Force $DataDir, $ControlDir | Out-Null
    $state = New-TuningState $bios $cpu

    $autoReboot = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name AutoReboot -ErrorAction SilentlyContinue).AutoReboot
    if ($autoReboot -eq 0) {
        Say '  Warning: Windows is set NOT to restart after a blue screen. Turn on "Automatically restart"' Yellow
        Say '  under System Properties > Advanced > Startup and Recovery, or a crash will wait for you.' Yellow
    }

    Say '  Creating a restore point...' DarkGray
    try { Checkpoint-Computer -Description 'Before CurveTuner' -RestorePointType MODIFY_SETTINGS -WarningAction SilentlyContinue }
    catch { Say "  (No restore point: $($_.Exception.Message))" DarkGray }

    $script:State = $state
    Save-State
    Write-History ('Setup done on {0} ({1}, {2} cores). BIOS values: {3}' -f $cpu.name, $cpu.generation, $cpu.numCores, (($bios | ForEach-Object { Format-Short $_ }) -join ' '))

    Say '  Protecting the CurveTuner folder and installing the background tasks...' DarkGray
    Protect-Folder
    Register-Tasks
    Start-ScheduledTask -TaskName $Config.EngineTask
    Say '  Started. Opening the dashboard...' Green
    Start-Sleep -Seconds 2
    Show-Dashboard
}
# Restarts the background engine with the files on disk (a test that was running is repeated)
function Restart-EngineTask {
    Stop-ScheduledTask -TaskName $Config.EngineTask -ErrorAction SilentlyContinue
    Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*CurveTuner.ps1*-Engine*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Stop-TestPrograms
    Start-ScheduledTask -TaskName $Config.EngineTask
}

# Installs a new version that was put in C:\CurveTuner-update
function Invoke-Update {
    Show-SetupHeader
    $newVersion = Get-UpdateVersion
    if (-not $newVersion) {
        Say '  No update is waiting.' Yellow
        Start-Sleep -Seconds 3
        return
    }

    Say "  Installing CurveTuner $newVersion (installed now: $Version)..." White
    $script:CcDir = Find-CoreCycler
    [void](Test-Prerequisites)

    Copy-Item -LiteralPath (Join-Path $UpdateDir 'CurveTuner.ps1') -Destination $Root -Force
    Copy-Item -Path (Join-Path $UpdateDir 'lib\*.ps1') -Destination (Join-Path $Root 'lib') -Force
    if (Test-Path -LiteralPath (Join-Path $UpdateDir 'CurveTuner.exe')) {
        Copy-Item -LiteralPath (Join-Path $UpdateDir 'CurveTuner.exe') -Destination $Root -Force
    }
    Protect-Folder
    Remove-Item -LiteralPath $UpdateDir -Recurse -Force
    Write-History "Updated to version $newVersion"

    if (Test-Path -LiteralPath $StateFile) {
        Restart-EngineTask
        Say '  The background engine was restarted with the new version (the current test is repeated).' Green
    }
    Say '  Done.' Green
    Start-Sleep -Seconds 3
}

function Invoke-Reset {
    Show-SetupHeader
    if ((Read-Choice '  Delete all tuning progress and start over?  [Y/N] ' @('Y', 'N')) -ne 'Y') { return }
    $script:CcDir = Find-CoreCycler
    [void](Test-Prerequisites)
    Stop-Engine
    Restore-BiosValues
    foreach ($f in @($StateFile, "$StateFile.bak", "$StateFile.tmp", $StatusFile)) { Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue }
    Write-History 'Progress reset'
    Say '  Progress deleted (history.log is kept). Start CurveTuner again to set it up anew.' Green
    Read-Host '  Press Enter to close' | Out-Null
}

function Invoke-Uninstall {
    Show-SetupHeader
    if ((Read-Choice '  Remove the CurveTuner background tasks?  [Y/N] ' @('Y', 'N')) -ne 'Y') { return }
    $script:CcDir = Find-CoreCycler
    [void](Test-Prerequisites)
    Stop-Engine
    Restore-BiosValues
    Unregister-ScheduledTask -TaskName $Config.EngineTask -Confirm:$false -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $Config.ViewTask -Confirm:$false -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $Config.LegacyTask -Confirm:$false -ErrorAction SilentlyContinue
    & icacls.exe $Root /reset /T /C /Q | Out-Null
    Say '  Removed. Your results stay in the data folder.' Green
    Say '  The PawnIO driver can be removed under Settings > Apps if you no longer need it.' DarkGray
    Read-Host '  Press Enter to close' | Out-Null
}
