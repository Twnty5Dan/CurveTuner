﻿<#
    CurveTuner 3 - automatic per-core Curve Optimizer tuning for AMD Ryzen 5000 / 7000 / 8000G / 9000 desktop
    CPUs. Setup measures the CPU (generation, Curve Optimizer range, cores, APIC IDs, board) once.
    Final values are entered in the BIOS by hand, once.

    A background engine (SYSTEM task, starts with Windows) sets test values from Windows with
    ryzen-smu-cli + PawnIO. They are temporary, so every restart brings back the BIOS values.
    Only one core at a time gets a test value. Crashes are blamed through the saved test state,
    the WHEA log and a heartbeat, and testing continues after a restart without logging in.

    Usage
      CurveTuner.exe              first time: setup (admin). After that: the dashboard
      CurveTuner.exe -Status      the dashboard
      CurveTuner.exe -Reset       delete all progress and start over (admin)
      CurveTuner.exe -Uninstall   remove the background tasks (admin)

    Files: lib\*.ps1 (code), data\ (state, logs), BIOS-values.txt (final values)
#>
[CmdletBinding()]
param(
    [switch] $Engine,       # the background engine (SYSTEM task)
    [switch] $View,         # the dashboard
    [switch] $ViewAtLogon,  # hidden at logon: opens the dashboard if there is something to see
    [switch] $Setup,
    [switch] $Reset,
    [switch] $Uninstall,
    [switch] $StartEngine,  # starts the engine task now (admin)
    [switch] $Update,       # installs the version waiting in C:\CurveTuner-update (admin)
    [switch] $Status,       # old name for -View
    [switch] $Auto,         # old name, from the BIOS-only version's logon task
    [switch] $FromLogon     # old name
)

$ErrorActionPreference = 'Stop'
$Root       = $PSScriptRoot
$ScriptPath = $MyInvocation.MyCommand.Path
$CcDir      = $null

foreach ($lib in 'Common', 'Cpu', 'Smu', 'Events', 'CoreCycler', 'Bench', 'Search', 'Engine', 'EngineSteps', 'Dashboard', 'Setup') {
    . (Join-Path $Root "lib\$lib.ps1")
}

if ($Engine) {
    Start-Engine
    exit
}

if ($ViewAtLogon -or $Auto -or $FromLogon) {
    Invoke-ViewAtLogon
    exit
}

# Set up = the state file exists AND can be read (if not, setup repairs it)
$installed  = (Test-Path -LiteralPath $StateFile) -and ($null -ne (Read-JsonFile $StateFile))
$wantsView  = $View -or $Status
$needsAdmin = $Setup -or $Reset -or $Uninstall -or $StartEngine -or $Update -or (-not $installed -and -not $wantsView)

if ($needsAdmin -and -not (Test-Admin)) {
    $passArgs = @()
    foreach ($name in 'Setup', 'Reset', 'Uninstall', 'StartEngine', 'Update') {
        if ($PSBoundParameters.ContainsKey($name)) { $passArgs += "-$name" }
    }
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $ScriptPath)) + $passArgs
    try { Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs -WorkingDirectory $Root }
    catch { Say 'CurveTuner needs admin rights for this.' Yellow; Start-Sleep -Seconds 3 }
    exit
}

try {
    $Host.UI.RawUI.WindowTitle = 'CurveTuner'
    if ($Uninstall)   { Invoke-Uninstall; exit }
    if ($Reset)       { Invoke-Reset; exit }
    if ($StartEngine) { Start-ScheduledTask -TaskName $Config.EngineTask; exit }
    if ($Update)      { Invoke-Update; exit }
    if ($Setup -or -not $installed) {
        if ($wantsView) { Say 'CurveTuner is not set up yet. Start CurveTuner from the desktop.' Yellow; Start-Sleep -Seconds 5; exit }
        Invoke-Setup
        exit
    }
    Show-Dashboard
}
catch {
    try { [Console]::CursorVisible = $true } catch { }
    Say ''
    Say ('ERROR: ' + $_.Exception.Message) Red
    Say $_.ScriptStackTrace DarkGray
    Read-Host 'Press Enter to close' | Out-Null
    exit 1
}
