﻿# CurveTuner - the dashboard. Shows what the background engine is doing; no admin rights needed.

$SeenFile = Join-Path $env:LOCALAPPDATA 'CurveTuner\alerts-seen.txt'

function Get-TriedTokens($C) {
    $tokens = @()
    $entries = @($C.history | Where-Object { $_.kind -in 'baseline', 'quick', 'confirm', 'combined', 'daily' -and $_.result -ne 'INTERRUPTED' })
    foreach ($e in ($entries | Select-Object -Last 9)) {
        $t = Format-Short $e.value
        $color = 'Green'
        if ($e.result -eq 'FAIL')    { $t += 'x'; $color = 'Red' }
        if ($e.result -eq 'STRETCH') { $t += 's'; $color = 'Yellow' }
        if ($e.result -eq 'PASS' -and $e.kind -eq 'confirm') { $t += '*'; $color = 'Cyan' }
        if ($e.kind -eq 'combined' -or $e.kind -eq 'daily') { $color = 'Magenta' }
        $tokens += @{ Text = $t; Color = $color }
    }
    return $tokens
}

function Format-Duration([double] $Minutes) {
    if ($Minutes -lt 1) { return 'less than a minute' }
    $h = [int][Math]::Floor($Minutes / 60)
    $m = [int][Math]::Round($Minutes - 60 * $h)
    if ($h -gt 0) { return ('{0} h {1:00} min' -f $h, $m) }
    return ('{0} min' -f $m)
}

function Get-EtaMinutes($S) {
    $doneCores = @($S.cores | Where-Object { $_.status -eq 'done' -and $_.startedAt -and $_.doneAt })
    $perCore = 60.0
    if ($doneCores.Count -gt 0) {
        # Median, so a core that sat paused for hours does not inflate the estimate
        $mins = @($doneCores | ForEach-Object { ((ConvertFrom-Iso $_.doneAt) - (ConvertFrom-Iso $_.startedAt)).TotalMinutes } | Sort-Object)
        $perCore = [Math]::Min(120, $mins[[int][Math]::Floor(($mins.Count - 1) / 2)])
    }
    $left = @($S.cores | Where-Object { $_.status -ne 'done' }).Count
    $combined = 50.0 + 5 * @($S.cores).Count
    switch ($S.phase) {
        'selftest' { return 5 + @($S.cores).Count * $perCore + $combined }
        'search'   { return $left * $perCore + $combined }
        'combined' { return $combined * (4 - [int]$S.combinedStage) / 4 }
    }
    return 0
}

# Line buffer: every line is a list of (text, color) segments, drawn without flicker
$script:Lines = New-Object System.Collections.ArrayList
function Add-Line { [void]$script:Lines.Add(@()) }
function Add-Seg([string] $Text, [string] $Color = 'Gray') {
    if ($script:Lines.Count -eq 0) { Add-Line }
    $script:Lines[$script:Lines.Count - 1] += , @{ Text = $Text; Color = $Color }
}
function Add-TextLine([string] $Text = '', [string] $Color = 'Gray') { Add-Line; if ($Text) { Add-Seg $Text $Color } }

function Show-Lines {
    $width = [Math]::Max(40, [Console]::WindowWidth - 1)
    $row = 0
    foreach ($line in $script:Lines) {
        if ($row -ge [Console]::BufferHeight - 1) { break }
        [Console]::SetCursorPosition(0, $row)
        $used = 0
        foreach ($seg in $line) {
            $text = $seg.Text
            if ($used + $text.Length -gt $width) { $text = $text.Substring(0, [Math]::Max(0, $width - $used)) }
            Write-Host $text -ForegroundColor $seg.Color -NoNewline
            $used += $text.Length
        }
        Write-Host (' ' * [Math]::Max(0, $width - $used)) -NoNewline
        $row++
    }
    # clear what is left from a longer previous screen
    for ($r = $row; $r -lt [Math]::Min($row + 6, [Console]::BufferHeight - 1); $r++) {
        [Console]::SetCursorPosition(0, $r)
        Write-Host (' ' * $width) -NoNewline
    }
    [Console]::SetCursorPosition(0, $row)
    $script:Lines.Clear()
}

function Build-Screen($S, $St) {
    $script:State = $S
    if (-not $script:CpuProfile -and $S.cpu) { Initialize-CpuConfig $S.cpu }
    $engineAlive = $St -and $St.time -and ((Get-Date) - (ConvertFrom-Iso $St.time)).TotalSeconds -lt 20

    $badge = '[RUNNING]'; $badgeColor = 'Green'
    if ($S.paused)                        { $badge = '[PAUSED]';   $badgeColor = 'Yellow' }
    elseif ($S.phase -eq 'bios')          { $badge = '[ENTER VALUES IN BIOS]'; $badgeColor = 'Cyan' }
    elseif ($S.phase -eq 'done')          { $badge = '[DONE]';     $badgeColor = 'Green' }
    elseif ($S.phase -eq 'error')         { $badge = '[STOPPED]';  $badgeColor = 'Red' }
    elseif (-not $engineAlive)            { $badge = '[NOT RUNNING]'; $badgeColor = 'Red' }

    Add-TextLine ' ================================================================================' DarkCyan
    Add-Line; Add-Seg ('  CurveTuner  -  automatic per-core Curve Optimizer for {0}   ' -f (Get-CpuShortName)) Cyan; Add-Seg $badge $badgeColor
    Add-TextLine ' ================================================================================' DarkCyan
    Add-TextLine

    if ($S.phase -in 'selftest', 'search', 'combined') {
        if ($S.paused) {
            Add-TextLine ('  Paused: ' + $S.pauseReason + '.  Press R to continue.') Yellow
        }
        elseif (-not $engineAlive) {
            Add-TextLine '  The background engine is not running. It starts with Windows; press S to start it now.' Red
        }
        elseif ($St.activity -eq 'testing' -and $null -ne $St.total) {
            $what = $St.stageName
            if ($null -ne $St.core -and [int]$St.core -ge 0) { $what = 'Core {0} at {1}  -  {2}' -f $St.core, (Format-Short $St.value), $St.stageName }
            elseif ($null -ne $St.activeCore) { $what = '{0}  (now on core {1})' -f $St.stageName, $St.activeCore }
            Add-TextLine ('  Now:   {0}    {1:mm\:ss} / {2:mm\:ss}' -f $what, [TimeSpan]::FromSeconds([double]$St.elapsed), [TimeSpan]::FromSeconds([double]$St.total)) White
        }
        else {
            Add-TextLine ('  Now:   ' + $St.activity) White
        }

        $done = @($S.cores | Where-Object { $_.status -eq 'done' }).Count
        $phaseText = @{ selftest = 'self-test'; search = 'finding each core''s limit'; combined = ('final validation, part {0} of 4' -f ([int]$S.combinedStage + 1)) }[$S.phase]
        Add-TextLine ('  Step:  {0}    cores finished: {1} of {2}    time left: about {3}' -f $phaseText, $done, @($S.cores).Count, (Format-Duration (Get-EtaMinutes $S)))
        Add-TextLine
    }

    Add-TextLine '   Core   BIOS   Tried (x = failed, s = stable but slower, * = confirmed)   Limit   Final   Clock' White
    Add-TextLine '   ----   ----   ---------------------------------------------------------   -----   -----   ---------' DarkGray
    foreach ($c in $S.cores) {
        Add-Line
        $mark = '  '
        if ($S.current -and $null -ne $S.current.core -and [int]$S.current.core -eq [int]$c.core) { $mark = '> ' }
        Add-Seg (' {0}{1,4}   {2,4}   ' -f $mark, $c.core, (Format-Short $S.bios[[int]$c.core])) $(if ($mark -eq '> ') { 'White' } else { 'Gray' })
        $used = 0
        foreach ($tk in (Get-TriedTokens $c)) {
            Add-Seg ($tk.Text + ' ') $tk.Color
            $used += $tk.Text.Length + 1
        }
        Add-Seg (' ' * [Math]::Max(0, 57 - $used))
        $last = @($c.history | Where-Object { $null -ne $_.effMHz }) | Select-Object -Last 1
        $clock = '-'
        if ($last) { $clock = '{0} MHz' -f $last.effMHz }
        $finalColor = 'Gray'
        if ($c.status -eq 'done') { $finalColor = 'Green' }
        Add-Seg ('   {0,5}   ' -f (Format-Short $c.limit))
        Add-Seg ('{0,5}' -f (Format-Short $c.final)) $finalColor
        Add-Seg ('   {0,9}' -f $clock)
    }
    Add-TextLine

    if ($S.phase -in 'bios', 'done') {
        foreach ($l in Get-BiosLines) { Add-TextLine ('  ' + $l) $(if ($l -match '<- change') { 'Yellow' } else { 'Gray' }) }
        if ($S.allCore -and $S.allCore.finalScore) {
            $gain = 100 * ([double]$S.allCore.finalScore / [double]$S.allCore.biosScore - 1)
            Add-TextLine ('  All-core: {0} MHz -> {1} MHz effective, score {2:+0.0;-0.0;0.0}%' -f $S.allCore.biosMHz, $S.allCore.finalMHz, $gain) Cyan
        }
        Add-TextLine
    }

    $alerts = @($S.alerts | Select-Object -Last 3)
    if ($alerts.Count -gt 0) {
        Add-TextLine '  Messages:' White
        foreach ($a in $alerts) {
            $color = @{ info = 'Gray'; success = 'Green'; warning = 'Yellow'; error = 'Red' }[[string]$a.level]
            if (-not $color) { $color = 'Gray' }
            Add-TextLine ('   {0}  {1}' -f (ConvertFrom-Iso $a.time).ToString('dd/MM HH:mm'), $a.text) $color
        }
        Add-TextLine
    }

    Add-TextLine '  Recent:' White
    foreach ($h in (Get-FileTail $HistoryFile 7)) {
        $color = 'DarkGray'
        if ($h -match 'FAILED|failed|crash') { $color = 'Red' }
        elseif ($h -match 'passed|confirmed|Checked') { $color = 'Green' }
        elseif ($h -match 'slower') { $color = 'Yellow' }
        if ($h.Length -gt 19) { $h = $h.Substring(11) }   # drop the date, keep the time
        Add-TextLine ('   ' + $h) $color
    }
    Add-TextLine
    $keys = '  [P] pause    [R] resume    [S] start engine    [Q] close this window (tuning continues in the background)'
    $upd = Get-UpdateVersion
    if ($upd -and $upd -ne $Version) {
        Add-TextLine ("  Update {0} is ready (installed: {1}). Press U to install it - needs admin, the current test is repeated." -f $upd, $Version) Yellow
        $keys += '    [U] update'
    }
    Add-TextLine $keys DarkCyan
}

function Send-EngineCommand([string] $Cmd) {
    try {
        Set-Content -LiteralPath $CommandFile -Value $Cmd -Encoding ASCII
        return $true
    }
    catch { return $false }
}

function Show-Dashboard {
    $Host.UI.RawUI.WindowTitle = 'CurveTuner'
    try {
        if ([Console]::WindowWidth -lt 112) { [Console]::WindowWidth = [Math]::Min(112, [Console]::LargestWindowWidth) }
        $rows = 36
        $S0 = Read-JsonFile $StateFile
        if ($S0) { $rows = 34 + @($S0.cores).Count }
        if ([Console]::WindowHeight -lt $rows) { [Console]::WindowHeight = [Math]::Min($rows, [Console]::LargestWindowHeight) }
    }
    catch { }
    Clear-Host
    try { [Console]::CursorVisible = $false } catch { }

    $note = ''
    $lastDraw = [datetime]::MinValue
    while ($true) {
        if (((Get-Date) - $lastDraw).TotalMilliseconds -ge 1500) {
            $S  = Read-JsonFile $StateFile
            $St = Read-JsonFile $StatusFile
            if (-not $S) {
                Add-TextLine '  CurveTuner is not set up yet. Start CurveTuner from the desktop.' Yellow
            }
            else {
                Build-Screen $S $St
                if ($S.alerts) {
                    $newest = (@($S.alerts) | Select-Object -Last 1).time
                    try { New-Item -ItemType Directory -Force (Split-Path $SeenFile) | Out-Null; Set-Content -LiteralPath $SeenFile -Value $newest } catch { }
                }
            }
            if ($note) { Add-TextLine ('  ' + $note) Yellow }
            Show-Lines
            $lastDraw = Get-Date
        }

        if ([Console]::KeyAvailable) {
            $key = [Console]::ReadKey($true).Key
            switch ($key) {
                'P' { if (Send-EngineCommand 'pause')  { $note = 'Pause sent - the current test stops within a few seconds and will be repeated later.' } }
                'R' { if (Send-EngineCommand 'resume') { $note = 'Resume sent.' } }
                'S' {
                    $note = 'Starting the engine (needs admin rights)...'
                    try { Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"{0}"' -f $ScriptPath), '-StartEngine') -Verb RunAs } catch { $note = 'Not started.' }
                }
                'U' {
                    if (Get-UpdateVersion) {
                        $note = 'Installing the update (needs admin rights)...'
                        try { Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $ScriptPath), '-Update') -Verb RunAs } catch { $note = 'Update not installed.' }
                    }
                }
                { $_ -in 'Q', 'Escape' } {
                    try { [Console]::CursorVisible = $true } catch { }
                    Clear-Host
                    return
                }
            }
            $lastDraw = [datetime]::MinValue
        }
        Start-Sleep -Milliseconds 150
    }
}

# Started hidden at logon: only opens the dashboard when there is something to see
function Invoke-ViewAtLogon {
    $S = Read-JsonFile $StateFile
    if (-not $S) { return }
    $open = $S.phase -ne 'done'
    if (-not $open -and $S.alerts) {
        $newest = (@($S.alerts) | Select-Object -Last 1).time
        $seen = ''
        try { $seen = (Get-Content -LiteralPath $SeenFile -ErrorAction Stop | Select-Object -First 1) } catch { }
        $open = ($newest -ne $seen)
    }
    if ($open) {
        Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $ScriptPath), '-View') -WorkingDirectory $Root
    }
}
