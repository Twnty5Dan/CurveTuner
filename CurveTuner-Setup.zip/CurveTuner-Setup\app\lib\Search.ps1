# CurveTuner - the per-core search. No hardware access in here, so it can be tested on its own.
#
# Per core:
#   1. Start at the BIOS value (known stable) and go more negative in steps of 3 with a quick test.
#   2. After the first fail, go back and continue in steps of 1 up to that fail.
#   3. Confirm the most negative passing value with a long test. A fail there moves it up by 1.
#   4. Final value = confirmed limit + safety margin.
# A value that is stable but makes the core slower (clock stretching) counts as a fail.

# History kinds that count for the search
$SearchKinds = @('before', 'baseline', 'quick', 'confirm')

function New-CoreRecord([int] $Core) {
    [pscustomobject]@{
        core         = $Core
        status       = 'search'   # search / confirm / done
        confirmValue = $null
        limit        = $null
        final        = $null
        note         = ''
        startedAt    = $null
        doneAt       = $null
        history      = @()
    }
}

# Results: PASS, FAIL, STRETCH (stable but slower = too far), INTERRUPTED (ignored)
function Add-CoreHistory($C, [string] $Kind, [int] $Value, [string] $Result, [string] $Detail = '', $Perf = $null, $Ref = $null) {
    $entry = [pscustomobject]@{
        time     = (Get-NowIso)
        kind     = $Kind
        value    = $Value
        result   = $Result
        detail   = $Detail
        effMHz   = $(if ($Perf) { $Perf.effMHz } else { $null })
        score    = $(if ($Perf) { $Perf.score } else { $null })
        refMHz   = $(if ($Ref) { $Ref.effMHz } else { $null })
        refScore = $(if ($Ref) { $Ref.score } else { $null })
    }
    $C.history = @($C.history) + $entry
}

# Least negative failing value and most negative passing value above it
function Get-SearchBounds($C) {
    $entries = @($C.history | Where-Object { $SearchKinds -contains $_.kind })
    $fails   = @($entries | Where-Object { $_.result -eq 'FAIL' -or $_.result -eq 'STRETCH' } | ForEach-Object { [int]$_.value })
    $passes  = @($entries | Where-Object { $_.result -eq 'PASS' } | ForEach-Object { [int]$_.value })

    $fail = $null
    if ($fails.Count -gt 0) { $fail = [int]($fails | Measure-Object -Maximum).Maximum }

    $pass = $null
    $valid = @($passes | Where-Object { $null -eq $fail -or $_ -gt $fail })
    if ($valid.Count -gt 0) { $pass = [int]($valid | Measure-Object -Minimum).Minimum }

    return @{ Pass = $pass; Fail = $fail }
}

function Set-CoreUnusable($C) {
    $C.status = 'done'
    $C.limit  = $Config.MaxValue
    $C.final  = $Config.MaxValue
    $C.note   = "not stable even at +$($Config.MaxValue), this core may be faulty"
    $C.doneAt = Get-NowIso
}

# The next test for a core: @{ Value; Profile } or $null when the core is finished
function Get-NextTest($C, [int] $Bios) {
    if ($C.status -eq 'done') { return $null }
    if ($C.status -eq 'confirm') { return @{ Value = [int]$C.confirmValue; Profile = 'confirm' } }

    $b = Get-SearchBounds $C

    if ($null -eq $b.Pass) {
        # Nothing passed yet: check the BIOS value first, and if even that failed, go up in big steps
        if ($null -eq $b.Fail) { return @{ Value = $Bios; Profile = 'quick' } }
        $v = [Math]::Min($b.Fail + $Config.CoarseStep, $Config.MaxValue)
        if ($v -le $b.Fail) { Set-CoreUnusable $C; return $null }
        return @{ Value = [int]$v; Profile = 'quick' }
    }

    $lowest = $Config.MinValue
    if ($null -ne $b.Fail) { $lowest = $b.Fail + 1 }

    if ($b.Pass - 1 -lt $lowest) {
        # Nothing left between the last pass and the first fail: confirm the limit with the long test
        $C.status       = 'confirm'
        $C.confirmValue = $b.Pass
        return @{ Value = [int]$b.Pass; Profile = 'confirm' }
    }

    if ($null -eq $b.Fail -or ($b.Pass - $b.Fail) -gt $Config.CoarseStep) {
        $v = [Math]::Max($b.Pass - $Config.CoarseStep, $lowest)   # big step
    }
    else {
        $v = $b.Pass - 1                                          # close to the edge: one step at a time
    }
    return @{ Value = [int]$v; Profile = 'quick' }
}

# Records the result of a finished test and moves the core forward
function Complete-Test($C, [int] $Value, [string] $Profile, [string] $Result, [string] $Detail = '', $Perf = $null, $Ref = $null) {
    Add-CoreHistory $C $Profile $Value $Result $Detail $Perf $Ref
    if ($Profile -ne 'confirm') { return }

    if ($Result -eq 'PASS') {
        $C.status = 'done'
        $C.limit  = $Value
        $C.final  = [int][Math]::Min($Value + $Config.SafetyMargin, $Config.MaxValue)
        $C.doneAt = Get-NowIso
    }
    elseif ($Result -eq 'FAIL') {
        if ($Value + 1 -gt $Config.MaxValue) { Set-CoreUnusable $C }
        else { $C.confirmValue = $Value + 1 }
    }
}

# A core failed during the final validation (at its final value): back it off by 1
function Set-CombinedFail($C, [string] $Detail) {
    Add-CoreHistory $C 'combined' ([int]$C.final) 'FAIL' $Detail
    $C.final = [int][Math]::Min([int]$C.final + 1, $Config.MaxValue)
}

# The value a core gets at every boot: its BIOS value, unless that value (or a less negative one)
# has failed at some point. Then 2 steps above the highest such fail (1 for a daily-use WHEA error).
function Get-SafeValue($C, [int] $Bios) {
    $bad = @($C.history | Where-Object { $_.result -eq 'FAIL' -and [int]$_.value -ge $Bios })
    if ($bad.Count -eq 0) { return $Bios }

    $safe = $Bios
    foreach ($e in $bad) {
        $step = 2
        if ($e.kind -eq 'daily') { $step = 1 }
        $safe = [Math]::Max($safe, [int]$e.value + $step)
    }
    return [int][Math]::Min($safe, $Config.MaxValue)
}
