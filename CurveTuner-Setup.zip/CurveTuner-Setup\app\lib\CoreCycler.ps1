# CurveTuner - running CoreCycler (Prime95 / y-cruncher) on one or more cores

function Find-CoreCycler {
    $found = Get-ChildItem -LiteralPath (Join-Path $Root 'CoreCycler') -Filter 'script-corecycler.ps1' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $found) { throw 'CoreCycler was not found in the CoreCycler folder next to CurveTuner.ps1' }

    $dir = $found.DirectoryName
    $original = Join-Path $dir 'config.original.ini'
    if (-not (Test-Path -LiteralPath $original) -and (Test-Path -LiteralPath (Join-Path $dir 'config.ini'))) {
        Copy-Item -LiteralPath (Join-Path $dir 'config.ini') -Destination $original
    }
    return $dir
}

# CoreCycler refuses to start without these and only says so in its own window,
# so they are checked up front. Returns a list of problems (empty = fine).
function Test-Prerequisites {
    $problems = @()

    # CoreCycler uses the first "dotnet" it finds. A 32-bit .NET without .NET 8 in Program Files (x86)
    # can come first, so the 64-bit one goes in front (only for this process and what it starts)
    $dotnet64 = Join-Path $env:ProgramFiles 'dotnet'
    if (Test-Path -LiteralPath (Join-Path $dotnet64 'dotnet.exe')) {
        $env:PATH = $dotnet64 + ';' + $env:PATH
    }

    $has8   = $false
    $dotnet = Get-Command 'dotnet' -ErrorAction SilentlyContinue
    if ($dotnet) {
        $shared = Join-Path (Split-Path $dotnet.Path) 'shared\Microsoft.NETCore.App'
        $has8 = @(Get-ChildItem -LiteralPath $shared -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^8\.' }).Count -gt 0
    }
    if (-not $has8) { $problems += '.NET 8 Runtime (x64) is missing: https://dotnet.microsoft.com/en-us/download/dotnet/8.0' }

    # Visual C++ 2015-2022, x86 and x64, at least 14.29 (same check as CoreCycler)
    $vcX86 = $false
    $vcX64 = $false
    $keys  = 'HKLM:\SOFTWARE\WoW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    foreach ($e in Get-ItemProperty -Path $keys -ErrorAction SilentlyContinue) {
        if ($e.DisplayName -notmatch '^Microsoft Visual C\+\+\D*(\d|-){4,9}.*(Redistributable|Minimum)') { continue }
        $ver = $null
        if (-not [version]::TryParse(([string]$e.DisplayVersion -replace '[^\d\.]', ''), [ref]$ver)) { continue }
        if ($ver.Major -gt 14 -or ($ver.Major -eq 14 -and $ver.Minor -ge 29)) {
            if ($e.DisplayName -match 'x64') { $vcX64 = $true } else { $vcX86 = $true }
        }
    }
    if (-not ($vcX86 -and $vcX64)) { $problems += 'Visual C++ Redistributable 2015-2022 (x86 AND x64) is missing: https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist' }

    if (-not (Get-Service -Name 'PawnIO' -ErrorAction SilentlyContinue)) {
        $problems += 'The PawnIO driver is not installed (winget install namazso.PawnIO)'
    }
    return $problems
}

function Get-StressProcesses {
    @(Get-Process | Where-Object {
        $path = $null
        try { $path = $_.Path } catch { }
        $path -and $path.StartsWith($CcDir, [StringComparison]::OrdinalIgnoreCase)
    })
}

# Stops CoreCycler itself and everything it started (Prime95, y-cruncher, helpers)
function Stop-TestPrograms {
    Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*script-corecycler.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Get-StressProcesses | Stop-Process -Force -ErrorAction SilentlyContinue
}

function Write-CoreCyclerConfig([int[]] $Cores, $Stage, [string] $LogName) {
    $ignore = @(0..($Config.NumCores - 1) | Where-Object { $Cores -notcontains $_ })

    $ini = @(
        '# Written by CurveTuner for a single run. The original config is in config.original.ini',
        '[General]',
        "stressTestProgram = $($Stage.Program)",
        "runtimePerCore = $($Stage.Minutes)m",
        'suspendPeriodically = 1',
        'coreTestOrder = Sequential',
        'skipCoreOnError = 1',
        'stopOnError = 0',
        "numberOfThreads = $($Stage.Threads)",
        'maxIterations = 1',
        "coresToIgnore = $($ignore -join ', ')",
        'restartTestProgramForEachCore = 1',
        'delayBetweenCores = 5',
        'beepOnError = 0',
        'flashOnError = 0',
        'lookForWheaErrors = 1',
        'treatWheaWarningAsError = 1',
        '',
        "[$($Stage.Section)]"
    )
    foreach ($key in $Stage.Options.Keys) { $ini += "$key = $($Stage.Options[$key])" }
    $ini += @(
        '',
        '[AutomaticTestMode]',
        'enableAutomaticAdjustment = 0',
        'enableResumeAfterUnexpectedExit = 0',
        '',
        '[Logging]',
        "name = $LogName",
        'useWindowsEventLog = 0',
        'flushDiskWriteCache = 1',
        '',
        '[Update]',
        'enableUpdateCheck = 0'
    )
    Set-Content -LiteralPath (Join-Path $CcDir 'config.ini') -Value $ini -Encoding ASCII
}

# Runs one stage on the given cores.
# $OnTick is called about every second with (elapsedSec, totalSec, activeCore) and may return 'abort'.
# Returns Status = pass / fail / inconclusive / abort / setup-error, plus ErrorCores, Detail and ActiveCore.
function Invoke-CoreCycler([int[]] $Cores, $Stage, [scriptblock] $OnTick) {
    $logName = 'CT_{0}' -f (Get-Date -Format 'MMdd_HHmmss')
    Stop-TestPrograms
    Write-CoreCyclerConfig $Cores $Stage $logName

    $start    = Get-Date
    $totalSec = $Stage.Minutes * 60 * $Cores.Count
    $deadline = $start.AddSeconds($totalSec + 60 * $Config.TimeoutExtraMin)
    $ccScript = Join-Path $CcDir 'script-corecycler.ps1'
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $ccScript)) -WorkingDirectory $CcDir -WindowStyle Minimized -PassThru
    $null = $proc.Handle   # keeps the handle so ExitCode can be read later

    $ending      = $null
    $sawStress   = $false
    $activeCore  = $null
    $logFile     = $null
    $lastCheck   = [datetime]::MinValue
    Write-Log ("CoreCycler started: {0} on core(s) {1}" -f $Stage.Name, ($Cores -join ','))

    while (-not $proc.WaitForExit(1000)) {
        $now     = Get-Date
        $elapsed = ($now - $start).TotalSeconds

        if (($now - $lastCheck).TotalSeconds -ge 5) {
            $lastCheck = $now

            # Watchdog: Prime95 / y-cruncher must be running within 3 minutes, otherwise CoreCycler is stuck on an error
            if (-not $sawStress) {
                $sawStress = (Get-StressProcesses).Count -gt 0
                if (-not $sawStress -and $elapsed -ge 180) { $ending = 'setup-error'; break }
            }

            # Which core CoreCycler is on right now (to blame the right one if the PC crashes)
            if (-not $logFile) {
                $logFile = Get-ChildItem -LiteralPath (Join-Path $CcDir 'logs') -Filter "$logName*.log" -ErrorAction SilentlyContinue | Select-Object -First 1
            }
            if ($logFile) {
                $hit = Get-FileTail $logFile.FullName 60 | Select-String -Pattern 'Set to Core (\d+)' | Select-Object -Last 1
                if ($hit) { $activeCore = [int]$hit.Matches[0].Groups[1].Value }
            }
        }

        if ($now -gt $deadline) { $ending = 'timeout'; break }

        if ($OnTick) {
            $answer = & $OnTick $elapsed $totalSec $activeCore
            if ($answer -eq 'abort') { $ending = 'abort'; break }
        }
    }

    if ($ending) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 2
    Stop-TestPrograms

    $result = @{ Status = ''; ErrorCores = @(); Detail = ''; ActiveCore = $activeCore }

    if ($ending -eq 'abort') { $result.Status = 'abort'; return $result }
    if ($ending -eq 'setup-error') {
        $result.Status = 'setup-error'
        $result.Detail = 'CoreCycler did not start Prime95 / y-cruncher within 3 minutes'
        return $result
    }

    # Read the CoreCycler log
    $completed = $false
    if (-not $logFile) {
        $logFile = Get-ChildItem -LiteralPath (Join-Path $CcDir 'logs') -Filter "$logName*.log" -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if ($logFile) {
        foreach ($line in [IO.File]::ReadAllLines($logFile.FullName)) {
            if ($line -match 'ERROR: At Core \d+ \(APIC ID (\d+) = Core (\d+)\)') {
                $result.ErrorCores += [int]$Matches[2]
                if (-not $result.Detail) { $result.Detail = "WHEA error (APIC ID $($Matches[1]))" }
            }
            elseif ($line -match 'ERROR: At Core (\d+)') {
                $result.ErrorCores += [int]$Matches[1]
                if (-not $result.Detail) { $result.Detail = "$($Stage.Program.ToLowerInvariant()) found a calculation error" }
            }
            elseif ($line -match 'Iterations:\s+\d+ started / (\d+) completed' -and [int]$Matches[1] -ge 1) {
                $completed = $true
            }
        }
    }

    # Our own WHEA check as a second opinion
    foreach ($w in @(Get-WheaErrors -Since $start)) {
        if ($null -ne $w.Core) {
            $result.ErrorCores += [int]$w.Core
            if (-not $result.Detail) { $result.Detail = "WHEA event $($w.Id) (APIC ID $($w.Apic))" }
        }
    }
    $result.ErrorCores = @($result.ErrorCores | Sort-Object -Unique)

    if ($result.ErrorCores.Count -gt 0) { $result.Status = 'fail'; return $result }

    if (-not $sawStress -and $proc.ExitCode -ne 0) {
        $result.Status = 'setup-error'
        $result.Detail = "CoreCycler stopped with error code $($proc.ExitCode) before it started a stress test"
        return $result
    }
    if ($ending -eq 'timeout') { $result.Status = 'inconclusive'; $result.Detail = 'the test hung and was stopped'; return $result }
    if (-not $completed)       { $result.Status = 'inconclusive'; $result.Detail = 'CoreCycler ended without finishing'; return $result }

    $result.Status = 'pass'
    return $result
}
